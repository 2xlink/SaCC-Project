package com.pion.app_login.activities;

import android.view.Menu;
import android.view.MenuItem;

import com.pion.app_login.R;

/**
 * Abstract class for the CreateEventActivity and CreateExpenseActivity
 *
 * Created by pion on 24/01/16.
 */
abstract class CreateActivity extends AppActivity {

    abstract void create();

    // TOOLBAR
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_create, menu);
        return true;
    }

    // action bar item click
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_create) {
            create();
        }
        return super.onOptionsItemSelected(item);
    }
}
