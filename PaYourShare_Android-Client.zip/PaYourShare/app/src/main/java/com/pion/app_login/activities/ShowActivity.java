package com.pion.app_login.activities;

import android.view.Menu;
import android.view.MenuItem;

import com.pion.app_login.R;

/**
 * Created by pion on 24/01/16.
 */
abstract class ShowActivity extends AppActivity {

    /**
     * launch the modify activity
     */
    abstract void goToModifyActivity();


    // TOOLBAR
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_modify, menu);
        return true;
    }

    // action bar item click
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_modify) {
            goToModifyActivity();
        } else if (id == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
