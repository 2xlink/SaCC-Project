package com.pion.app_login.activities;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.text.InputType;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.support.v7.widget.Toolbar;

import com.pion.app_login.Expense;
import com.pion.app_login.R;
import com.pion.app_login.app.AppConfig;
import com.pion.app_login.app.VolleyRequest;
import com.pion.app_login.database.ExpenseDB;

import java.util.ArrayList;
import java.util.List;

/**
 * Activity to modify the expense
 *
 * Created by pion on 28/12/15.
 */
public class ModifyExpenseActivity extends ModifyActivity {
    public static String TAG = ModifyExpenseActivity.class.getSimpleName();

    private Toolbar toolbar;

    private EditText modify_name;
    private EditText modify_amount;
    private EditText modify_type;
    private Spinner modify_payer;
    private LinearLayout l_show_part;

    //private List<TextView> exp_list_tv_parts;
    private List<EditText> exp_list_share_text_view;

    private Expense expense;
    private List<String> exp_list_ids;
    private List<String> exp_list_emails;
    private List<String> exp_list_shares;

    @Override
    public void onCreate(Bundle savedInstancesState)
    {
        super.onCreate(savedInstancesState);
        setContentView(R.layout.modify_expense);
        Log.d(TAG, "ModifyExpenseActivity launched");

        // toolbar
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        // add a return button to go to the previous activity
        final ActionBar supportActionBar = getSupportActionBar();
        supportActionBar.setDisplayHomeAsUpEnabled(true);

        exp_list_share_text_view = new ArrayList<>();
        exp_list_shares = new ArrayList<>();


        if (session.isLoggedIn()) {
            expense = (Expense) getIntent().getSerializableExtra("expense");
            exp_list_ids = expense.getIdPart();
            exp_list_emails = expense.getEmailPart();
            //exp_list_shares = expense.getSharePart();

            Log.d(TAG, "expense to modify: " + expense.toString());

            modify_name = (EditText) findViewById(R.id.modify_exp_name);
            modify_amount = (EditText) findViewById(R.id.modify_exp_value);
            modify_type = (EditText) findViewById(R.id.modify_exp_type);

            modify_name.setText(expense.getName());
            modify_amount.setText(expense.getAmount());
            modify_type.setText(expense.getType());

            // Use of spinner
            // https://openclassrooms.com/courses/creez-des-applications-pour-android/des-widgets-plus-avances-et-des-boites-de-dialogue#/id/r-2031617
            modify_payer = (Spinner) findViewById(R.id.modify_exp_spinner_payer);
            ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                    android.R.layout.simple_spinner_item, expense.getEmailPart());
            // default layout to use android.R.layout.simple_spinner_dropdown_item
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

            modify_payer.setAdapter(adapter);
            modify_payer.setSelection(
                    expense.getIdPart().indexOf(expense.getIdCreator()));

            l_show_part = (LinearLayout) findViewById(R.id.modify_exp_layout_show_participants);

            // show the share of each participant
            if (expense.notEmpty()) {
                for (int i = 0; i < expense.nbrPart(); i++) {
                    showUserShare(expense.getEmailPart().get(i),
                            expense.getSharePart().get(i));
                }
            } else {
                Log.d(TAG, "Expense empty: " + expense.toString());
            }

        } else {
            // user not logged in -> take him to the login activity
            Log.d(TAG, "User is not logged in");
            toLogin(ModifyExpenseActivity.this);
        }
    }

    /**
     * Show on the activity the email and the share of the participant
     * @param email
     * @param share_value
     */
    public void showUserShare(String email, String share_value)
    {

        Resources r = getApplicationContext().getResources();
        int height = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
                50, r.getDisplayMetrics());
        final int padding = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
                10, r.getDisplayMetrics());

        LinearLayout lLayout = new LinearLayout(this);
        lLayout.setOrientation(LinearLayout.HORIZONTAL);
        lLayout.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView participant = new TextView(this);
        participant.setText(email);
        participant.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 20);
        participant.setTextColor(Color.parseColor("#222222"));
        participant.setSingleLine();
        participant.setPadding(padding, padding, padding, padding);
        participant.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, height, 1f));

        EditText share = new EditText(this);
        share.setText(share_value);
        share.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 20);
        share.setTextColor(ContextCompat.getColor(getApplicationContext(),
                R.color.white));
        share.setTypeface(null, Typeface.BOLD);
        share.setGravity(Gravity.CENTER);
        share.setSingleLine();
        share.setInputType(InputType.TYPE_CLASS_NUMBER);
        share.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, height, 3f));

        // add the share edit text to the list
        exp_list_share_text_view.add(share);

        lLayout.addView(participant);
        lLayout.addView(share);

        l_show_part.addView(lLayout);

    }

    public void update()
    {
        // TODO save the updates in database and object and send it to the server
        String name = modify_name.getText().toString().trim();
        String amount = modify_amount.getText().toString().trim();
        String type = modify_type.getText().toString().trim();

        String id_creator = getIdFromEmail(modify_payer.getSelectedItem().toString());

        if (!name.isEmpty() && !amount.isEmpty()) {
            // search for one share not null
            boolean oneShareNotNull = false;
            for (EditText share : exp_list_share_text_view) {
                exp_list_shares.add(share.getText().toString());
                if (!share.getText().toString().equals("0")) {
                    oneShareNotNull = true;
                }
            }
            if (oneShareNotNull) {
                expense.setName(name);
                expense.setAmount(amount);
                expense.setType((type.isEmpty()) ? "" : type);
                expense.setIdCreator(id_creator);
                expense.setIdPart(exp_list_ids);
                expense.setEmailPart(exp_list_emails);
                expense.setSharePart(exp_list_shares);
                expense.setVersion(expense.getVersion() + 1);
                // TODO store the date of the last modification
                //expense.setModifiedAt(getDateTime());

                // store the updated expense on the server
                if (isNetworkAvailable()) { // if connection available
                    VolleyRequest vr = new VolleyRequest(getApplicationContext());
                    vr.expenseToServer(expense, user.getToken(), AppConfig.URL_UPDATE_EXPENSE, 0);
                } else {
                    Log.d(TAG, "No connection to internet");
                    Toast.makeText(getApplicationContext(),
                            "No connection to internet, couldn't store the expense on the server",
                            Toast.LENGTH_SHORT).show();
                }

                // store the event in local database
                (new ExpenseDB(handler)).updateExpense(expense);
                Log.d(TAG, "Expense updated in local database: " + expense.toString());

                Intent intent = new Intent();
                intent.putExtra("expense", expense);
                setResult(Activity.RESULT_OK, intent);
                finish();

            } else {
                Toast.makeText(getApplicationContext(),
                        "At least a participant must have a positive share", Toast.LENGTH_LONG)
                        .show();
            }
        } else {
            Toast.makeText(getApplicationContext(),
                    "Please give a name and a value to the expense", Toast.LENGTH_LONG)
                    .show();
        }
    }

    /**
     * Get the id of a user bind to the expense
     * @param email
     * @return the id of the user
     */
    public String getIdFromEmail(String email)
    {
        return exp_list_ids.get(exp_list_emails.indexOf(email));
    }
}
