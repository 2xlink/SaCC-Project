package com.pion.app_login.activities;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.Toolbar;
import android.text.InputType;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;

import com.pion.app_login.Event;
import com.pion.app_login.Expense;
import com.pion.app_login.R;
import com.pion.app_login.app.AppConfig;
import com.pion.app_login.app.AppController;
import com.pion.app_login.app.HttpsTrustManager;
import com.pion.app_login.app.VolleyRequest;
import com.pion.app_login.database.ExpenseDB;
import com.pion.app_login.database.UserDB;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

// TODO use different currencies

/**
 * Activity ot create an expense
 * Able to choose who has paid, how many shares for each participants
 *
 * Created by pion on 07/12/15.
 */
public class CreateExpenseActivity extends CreateActivity {
    private static final String TAG = CreateExpenseActivity.class.getSimpleName();

    private Toolbar toolbar;

    private EditText inputName;
    private EditText inputAmount;
    private EditText inputType;

    private Spinner spinner_payer;

    private LinearLayout layout;

    private Expense expense;
    private Event event;
    private List<String> list_ids;
    private List<String> list_emails;
    private List<String> list_shares;

    private List<TextView> list_participants;
    private List<EditText> list_edit_shares;

    private int id = 0;

    @Override
    public void onCreate(Bundle savedInstancesState)
    {
        super.onCreate(savedInstancesState);
        setContentView(R.layout.create_expense);

        Log.d(TAG, "CreateExpenseActivity launched");

        // toolbar
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        // add a return button to go to the previous activity
        final ActionBar supportActionBar = getSupportActionBar();
        supportActionBar.setDisplayHomeAsUpEnabled(true);

        inputName = (EditText) findViewById(R.id.expense_name);
        inputAmount = (EditText) findViewById(R.id.expense_value);
        inputType = (EditText) findViewById(R.id.expense_type);

        spinner_payer = (Spinner) findViewById(R.id.spinner_payer);

//        payer = (TextView) findViewById(R.id.expense_payer);


        layout = (LinearLayout) findViewById(R.id.layout_show_participants);

        event = (Event) getIntent().getSerializableExtra("event");
        list_ids = event.getIdUsers();
        list_emails = event.getEmailUsers();

        expense = new Expense();

        list_shares = new ArrayList<>();

        list_participants = new ArrayList<>();
        list_edit_shares = new ArrayList<>();


        // check if user already logged in or not
        if (session.isLoggedIn()) {

            // Use of spinner
            // https://openclassrooms.com/courses/creez-des-applications-pour-android/des-widgets-plus-avances-et-des-boites-de-dialogue#/id/r-2031617
            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, list_emails);
            // default layout to use android.R.layout.simple_spinner_dropdown_item
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

            spinner_payer.setAdapter(adapter);

            for (String email : list_emails) {
                addUserShare(email);
            }

        } else {
            // user not logged in -> take him to the login activity
            Log.d(TAG, "User is not logged in");
            toLogin(CreateExpenseActivity.this);
        }

    }

    /**
     *
     * @param email
     */
    public void addUserShare(String email)
    {
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        );

        Resources r = getApplicationContext().getResources();
        int height = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
                50, r.getDisplayMetrics());
        final int padding = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
                10, r.getDisplayMetrics());

        LinearLayout lLayout = new LinearLayout(this);
        lLayout.setOrientation(LinearLayout.HORIZONTAL);
        lLayout.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView participant = new TextView(this);
//        participant.setId(0);
        participant.setText(email);
        participant.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 20);
        participant.setTextColor(Color.parseColor("#222222"));
        participant.setSingleLine();
        participant.setPadding(padding, padding, padding, padding);
        participant.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, height, 1f));

        list_participants.add(participant);

        EditText share = new EditText(this);
        share.setId(id);
        share.setText("0");
        share.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 20);
        share.setTextColor(Color.parseColor("#ffffff"));
        share.setTypeface(null, Typeface.BOLD);
        share.setGravity(Gravity.CENTER);
        share.setSingleLine();
        share.setInputType(InputType.TYPE_CLASS_NUMBER);
        share.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, height, 3f));

        list_edit_shares.add(share);

        lLayout.addView(participant);
        lLayout.addView(share);

        layout.addView(lLayout);

        id ++;

    }

    /**
     * create expense method
     * check if the fields are correctly fill and then create the expense
     * or inform the user of an error, incorrect input
     */
    public void create()
    {
        String name = inputName.getText().toString().trim();
        String amount = inputAmount.getText().toString().trim();
        String type = inputType.getText().toString().trim();

        String id_creator = getIdFromEmail(spinner_payer.getSelectedItem().toString());

        if (!name.isEmpty() && !amount.isEmpty()) {
            boolean oneShareNotNull = false;
            for (EditText share : list_edit_shares) {
                list_shares.add(share.getText().toString());
                if (!share.getText().toString().equals("0")) {
                    oneShareNotNull = true;
                }
            }
            if (oneShareNotNull) {
                expense.setId(UUID.randomUUID().toString());
                expense.setIdEvent(event.getId());
                expense.setName(name);
                expense.setAmount(amount);
                expense.setType((type.isEmpty()) ? "" : type);
                expense.setIdCreator(id_creator);
                expense.setIdPart(list_ids);
                expense.setEmailPart(list_emails);
                expense.setSharePart(list_shares);
                expense.setVersion(0);
                expense.setCreatedAt(getDateTime());

                if (isNetworkAvailable()) { // if connection available
                    VolleyRequest vr = new VolleyRequest(getApplicationContext(), pDialog);
                    vr.expenseToServer(expense, user.getToken(), AppConfig.URL_CREATE_EXPENSE, 0);
                } else {
                    Log.d(TAG, "No connection to internet");
                    Toast.makeText(getApplicationContext(),
                            "No connection to internet, couldn't store the expense on the server",
                            Toast.LENGTH_SHORT).show();
                }
                createLocalExpense(expense);

                Intent intent = new Intent();
                intent.putExtra("new_expense", expense);
                setResult(Activity.RESULT_OK, intent);
                finish();

            } else {
                Toast.makeText(getApplicationContext(),
                        "At least a participant must have a positive share", Toast.LENGTH_LONG)
                        .show();
            }
        } else {
            Toast.makeText(getApplicationContext(),
                    "Please give a name and a value to the expense", Toast.LENGTH_LONG)
                    .show();
        }
    }

    public void createLocalExpense(Expense expense)
    {
        if (expense != null) {
            (new ExpenseDB(handler)).addExpense(expense);
            Log.d(TAG, "Expense  added to local database: " + expense.toString());
        } else {
            Log.d(TAG, "Error: the expense is null");
        }
//        Log.d(TAG, "expense: " + expense.toString());
    }

    /**
    * Get the id of a user bind to the expense
    * @param email
    * @return the id of the user
    */
    public String getIdFromEmail(String email)
    {
        return list_ids.get(list_emails.indexOf(email));
    }

}
