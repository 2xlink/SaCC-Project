package com.pion.app_login;

import android.content.Context;
import android.content.res.Resources;
import android.support.v4.content.ContextCompat;
import android.text.InputType;
import android.util.TypedValue;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Class with function to create/add paricular views to an activity
 *
 * Created by pion on 24/01/16.
 */
public class UserToView {
    private static EditText input;
    private static ImageButton add_button;

    private static TextView user_view;
    private static ImageButton rm_button;
    private static LinearLayout layout_user;

    /**
     * add an input for a user to the activity in parameter
     * show an edit text and a button to add the new user
     * @param context
     */
    public static void inputUserToView(Context context)
    {
        Resources r = context.getResources();
        int height = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
                50, r.getDisplayMetrics());
        final int padding = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
                10, r.getDisplayMetrics());

        // input for the email of the participants
        input = new EditText(context);
        input.setId(0);
        input.setHint("Email");
        input.setSingleLine();
        input.setInputType(InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        input.setTextColor(ContextCompat.getColor(context,
                R.color.input_text));
        input.setHintTextColor(ContextCompat.getColor(context,
                R.color.input_hint));
        input.setBackgroundColor(ContextCompat.getColor(context,
                R.color.white));
        input.setPadding(padding, padding, padding, padding);
        input.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, height, 1f));
        input.getLayoutParams().height = height;

        add_button = new ImageButton(context);
        add_button.setImageDrawable(ContextCompat.getDrawable(context,
                R.drawable.ic_add_white_24dp));
        add_button.setBackgroundColor(ContextCompat.getColor(context,
                R.color.colorAccentBright));
        add_button.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, height, 3f));
    }

    /**
     * add an input for a user to the activity in parameter
     * show a text view and a button to remove the new user
     * @param context
     */
    public static void addUserToView(Context context, String email_user)
    {
        Resources r = context.getResources();
        int height = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
                50, r.getDisplayMetrics());
        final int padding = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
                10, r.getDisplayMetrics());
        int txt_size = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
                10, r.getDisplayMetrics());
        LinearLayout.LayoutParams layout_params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, height);
        layout_params.setMargins(0, 0, 0, padding);

        // create the views representing each participant to the event
        layout_user = new LinearLayout(context);
        layout_user.setLayoutParams(layout_params);
        layout_user.setOrientation(LinearLayout.HORIZONTAL);

        user_view = new TextView(context);
        user_view.setText(email_user);
        user_view.setTextSize(txt_size);
        user_view.setPadding(padding, padding, padding, padding);
        user_view.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, height, 1f));

        rm_button = new ImageButton(context);
        rm_button.setImageDrawable(ContextCompat.getDrawable(context,
                R.drawable.ic_clear_white_24dp));
        rm_button.setBackgroundColor(ContextCompat.getColor(context,
                R.color.colorAccentBright));
        rm_button.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, height, 3f));

        layout_user.addView(user_view);
        layout_user.addView(rm_button);
    }

    public static EditText getInput() { return input; }
    public static ImageButton getAddButton() { return add_button; }

    public static TextView getEmailView() { return user_view; }
    public static ImageButton getRmButton() { return rm_button; }
    public static LinearLayout getLayoutUser() { return layout_user; }
}
