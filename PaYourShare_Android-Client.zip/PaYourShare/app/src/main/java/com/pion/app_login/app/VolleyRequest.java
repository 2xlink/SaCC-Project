package com.pion.app_login.app;

import android.app.ProgressDialog;
import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;

import com.pion.app_login.Event;
import com.pion.app_login.Expense;
import com.pion.app_login.res.Resource;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by pion on 22/01/16.
 */
public class VolleyRequest {
    private static final String TAG = VolleyRequest.class.getSimpleName();

    private Context context;
    private ProgressDialog pDialog;

    public  VolleyRequest() {
        this.context = null;
        this.pDialog = null;
    }
    public VolleyRequest(Context context) {
        this.context = context;
        this.pDialog = null;
    }
    public VolleyRequest(Context context, ProgressDialog pDialog) {
        this.context = context;
        this.pDialog = pDialog;
    }


    /**
     * createServerEvent - sent the event infos as JSON file to the server
     * @param event to store on the server
     * @param token of the user
     * @param url of the request
     * @param flag if set to 1, show a progress dialog during the request ; if 0 don't show it
     */
    public void eventToServer(final Event event, final String token, String url, final int flag)
    {
        Log.d(TAG, "Upload event to server: " + event.toString());
        HttpsTrustManager.allowAllSSL();

        // tag used to cancel the request
        String tag_string_req = "req_create_event";

        // create a progress dialog if the flag is set to 1
        if (flag == 1) {
            pDialog.setMessage("Storing the event on server...");
            Resource.showDialog(pDialog);
        }

        // create the json file to send to the server
        String arrayUsers = "[";
        for (int i=0; i < event.nbrUsers(); i++) {
            if (i == 0) {
                arrayUsers += "{";
            } else {
                arrayUsers += ",{";
            }
            arrayUsers += "\"email\":\"" + event.getEmailUsers().get(i) + "\","
                    + "\"id\":\"" + event.getIdUsers().get(i) + "\""
                    + "}";
        }
        arrayUsers += "]";

        String json = "{\"token\":\"" + token + "\","
                + "\"id\":\"" + event.getId() + "\","
                + "\"name\":\"" + event.getName() + "\","
                + "\"desc\":\"" + event.getDesc() + "\","
                + "\"creatorId\":\"" + event.getIdCreator() + "\","
                + "\"version\":\"" + event.getVersion() + "\","
                + "\"users\":" + arrayUsers
                + "}";

        Log.d(TAG, "Json event : " + json);

        JSONObject jObj = null;
        try {
            jObj = new JSONObject(json);

            JsonObjectRequest jObjReq = new JsonObjectRequest(Request.Method.POST,
                    url , jObj, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                    Log.d(TAG, "CreateEvent response: " + response.toString());

                    try {
                        boolean status = response.getBoolean("status");

                        // check the status of the answer in json
                        if (status) {
                            // add the id to the event
                            //event.setId(response.getString("id"));
                            Log.d(TAG, "Event stored on server: " + event.toString());
                        } else {
                            // error occurred in creation of the event on the server
                            Log.d(TAG, "Error storage of the event on server");
                        }
                    } catch (JSONException e) {
                        // JSON error
                        e.printStackTrace();
                        Log.d(TAG, "JSON error " + e.getMessage());
                    }

                    // disable the progress dialog if the flag is set to 1
                    if (flag == 1) {
                        Resource.hideDialog(pDialog);
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError errorV) {
                    Log.e(TAG, "CreateEvent volley request error: " + errorV.getMessage());
                    Toast.makeText(context,
                            "Connection error, couldn't store the event on the server",
                            Toast.LENGTH_LONG).show();

                    // disable the progress dialog if the flag is set to 1
                    if (flag == 1) {
                        Resource.hideDialog(pDialog);
                    }
                }
            });

            // Adding request to request queue
            AppController.getInstance().addToRequestQueue(jObjReq, tag_string_req);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    /**
     * createServerExpense - sent the expense infos as JSON file to the server
     * @param expense to store on the server
     * @param token of the user
     * @param url of the request
     * @param flag if set to 1, show a progress dialog during the request ; if 0 don't show it
     */
    public void expenseToServer(final Expense expense, final String token, String url, final int flag)
    {
        Log.d(TAG, "Upload expense to server: " + expense.toString());
        HttpsTrustManager.allowAllSSL();

        // tag used to cancel the request
        String tag_string_req = "req_create_event";

        // create a progress dialog if the flag is set to 1
        if (flag == 1) {
            pDialog.setMessage("Storing the expense on server...");
            Resource.showDialog(pDialog);
        }

        // create the json file to send to the server
        String arrayShares = "[";
        for (int i=0; i < expense.nbrPart(); i++) {
            if (i == 0) {
                arrayShares += "{";
            } else {
                arrayShares += ",{";
            }
            arrayShares += "\"id\":\"" + expense.getIdPart().get(i) + "\","
                    + "\"share\":\"" + expense.getSharePart().get(i) + "\""
                    + "}";
        }
        arrayShares += "]";

        String json = "{\"token\":\"" + token + "\","
                + "\"id\":\"" + expense.getId() + "\","
                + "\"eventId\":\"" + expense.getIdEvent() + "\","
                + "\"name\":\"" + expense.getName() + "\","
                + "\"type\":\"" + expense.getType() + "\","
                + "\"amount\":\"" + expense.getAmount() + "\","
                + "\"creatorId\":\"" + expense.getIdCreator() + "\","
                + "\"version\":\"" + expense.getVersion() + "\","
                + "\"shares\":" + arrayShares
                + "}";

        Log.d(TAG, "Json expense : " + json);

        JSONObject jObj = null;
        try {
            jObj = new JSONObject(json);

            JsonObjectRequest jObjReq = new JsonObjectRequest(Request.Method.POST,
                    url , jObj, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                    Log.d(TAG, "CreateExpense Response: " + response.toString());

                    try {
                        boolean status = response.getBoolean("status");

                        // check the status of the answer in json
                        if (status) {
                            // add the id to the event
                            //event.setId(response.getString("id"));
                            Log.d(TAG, "Expense stored on server: " + expense.toString());
                        } else {
                            // error occurred in creation of the event on the server
                            Log.d(TAG, "Error storage of the expense on server");
                        }
                    } catch (JSONException e) {
                        // JSON error
                        e.printStackTrace();
                        Log.d(TAG, "JSON error " + e.getMessage());
                    }

                    // disable the progress dialog if the flag is set to 1
                    if (flag == 1) {
                        Resource.hideDialog(pDialog);
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError errorV) {
                    Log.e(TAG, "CreateExpense volley request error: " + errorV.getMessage());
                    Toast.makeText(context,
                            "Connection error, couldn't store the expense on the server",
                            Toast.LENGTH_LONG).show();

                    // disable the progress dialog if the flag is set to 1
                    if (flag == 1) {
                        Resource.hideDialog(pDialog);
                    }
                }
            });

            // Adding request to request queue
            AppController.getInstance().addToRequestQueue(jObjReq, tag_string_req);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
