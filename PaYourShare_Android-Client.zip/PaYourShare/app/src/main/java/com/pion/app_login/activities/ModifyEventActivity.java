package com.pion.app_login.activities;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.ViewManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;

import com.pion.app_login.Event;
import com.pion.app_login.Expense;
import com.pion.app_login.R;
import com.pion.app_login.UserToView;
import com.pion.app_login.app.AppConfig;
import com.pion.app_login.app.AppController;
import com.pion.app_login.app.HttpsTrustManager;
import com.pion.app_login.app.VolleyRequest;
import com.pion.app_login.database.EventsDB;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Activity to modify the event infos
 * TODO create a super class for Create, Show and Modify Event
 * Created by pion on 28/12/15.
 */
public class ModifyEventActivity extends ModifyActivity {
    public static String TAG = ModifyEventActivity.class.getSimpleName();

    private Toolbar toolbar;

    private EditText modify_name;
    private EditText modify_desc;

    private LinearLayout l_list_part;
    private LinearLayout l_add_part;

    private EditText name_part;

    private Event event;
    private List<String> ev_list_ids;
    private List<String> ev_list_emails;

    private List<TextView> list_email_tv;
    private List<ImageButton> list_rm_btn;
    private List<LinearLayout> list_layout_users;

    @Override
    public void onCreate(Bundle savedInstancesState) {
        super.onCreate(savedInstancesState);
        setContentView(R.layout.modify_event);
        Log.d(TAG, "ModifyEventActivity launched");

        // toolbar
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        // add a return button to go to the previous activity
        final ActionBar supportActionBar = getSupportActionBar();
        supportActionBar.setDisplayHomeAsUpEnabled(true);

        if (session.isLoggedIn()) {

            // get the event to modify
            event = (Event) getIntent().getSerializableExtra("event");
            ev_list_ids = event.getIdUsers();
            ev_list_emails = event.getEmailUsers();

            Log.d(TAG, "event to modify: " + event.toString());


            modify_name = (EditText) findViewById(R.id.modify_event_name);
            modify_desc = (EditText) findViewById(R.id.modify_event_desc);

            // show the properties of the current event
            // use of edit texts to allow modifications
            modify_name.setText(event.getName());
            modify_desc.setText(event.getDesc());

            l_list_part = (LinearLayout) findViewById(R.id.modify_event_list_participants);
            l_add_part = (LinearLayout) findViewById(R.id.modify_event_add_participants);

            list_email_tv = new ArrayList<>();
            list_rm_btn = new ArrayList<>();
            list_layout_users = new ArrayList<>();

            // show each user of an event
            // add a remove button
            for (String email_user : ev_list_emails) {
                // create the views representing each participant to the event
                UserToView.addUserToView(this, email_user);
                LinearLayout l_part = UserToView.getLayoutUser();
                TextView email = UserToView.getEmailView();
                final ImageButton rm_part = UserToView.getRmButton();

                // store in lists of view and button in order to easily refer to them
                list_email_tv.add(email);
                list_rm_btn.add(rm_part);
                list_layout_users.add(l_part);

                // remove user of the event
                // if possible :
                // - the user must not be the creator of the event
                // - the user must not be a participant to an expense of the event
                rm_part.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // get the position of the user in the lists
                        int i = list_rm_btn.indexOf(rm_part);

                        String rm_id = event.getIdUsers().get(i);
                        String rm_email = event.getEmailUsers().get(i);

                        // check if the user is the creator of the event
                        if (rm_id.equals(event.getIdCreator())) {
                            Toast.makeText(getApplicationContext(),
                                    "Could not remove the owner of the event",
                                    Toast.LENGTH_SHORT).show();
                        }
                        // check if the user participates to expenses
                        else if (hasExpense(rm_id)) {
                            Toast.makeText(getApplicationContext(),
                                    "Could not remove a participant who participates to an expense",
                                    Toast.LENGTH_SHORT).show();
                        } else { // if not, the user can be safely removed of the event
                            // remove the layout from the view
                            ((ViewManager) list_layout_users.get(i).getParent()).
                                    removeView(list_layout_users.get(i));

                            // remove the objects from the lists
                            list_layout_users.remove(i);
                            list_rm_btn.remove(i);
                            list_email_tv.remove(i);

                            // remove the user from the event object
                            ev_list_ids.remove(rm_id);
                            ev_list_emails.remove(rm_email);

                            // remove the button from the list
                            list_rm_btn.remove(rm_part);
                            Log.d(TAG, "Participant removed from the event: " + ev_list_emails.toString());

                            Log.d(TAG, "listIds: " + ev_list_ids.toString()
                                    + " - listEmails: " + ev_list_emails.toString());
                        }

                    }
                });

                // add the layout to the view
                l_list_part.addView(l_part);

            }

            // input for the names of a new user
            UserToView.inputUserToView(this);
            name_part = UserToView.getInput();
            ImageButton add_part = UserToView.getAddButton();

            l_add_part.addView(name_part);
            l_add_part.addView(add_part);

            add_part.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final String new_email = name_part.getText().toString().trim();

                    if (!new_email.matches("")) { // if email not empty
                        if (!event.getEmailUsers().contains(new_email)) { // if email not already added
                            // TODO when the connexion is available check if the new user already has an account or not
                            if (isNetworkAvailable()) { // if connection available
                                // TODO: use a specific function
                                checkValidEmail(new_email);
                            } else {
                                // if no connection available
                                // show a box and ask the user if he really wants to add the user
                                Log.d(TAG, "No connection to internet");
                                Toast.makeText(getApplicationContext(),
                                        "No connection to internet, internet is required to add a participant",
                                        Toast.LENGTH_SHORT).show();

                                DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        switch (which){
                                            case DialogInterface.BUTTON_POSITIVE:
                                                //Yes button clicked
                                                addParticipantToView(UUID.randomUUID().toString(), new_email);
                                                break;

                                            case DialogInterface.BUTTON_NEGATIVE:
                                                //No button clicked
                                                break;
                                        }
                                    }
                                };

                                AlertDialog.Builder builder = new AlertDialog.Builder(v.getContext());
                                builder.setMessage("Do you really want to add " + new_email + " to this event?")
                                        .setPositiveButton("Yes", dialogClickListener)
                                        .setNegativeButton("No", dialogClickListener).show();
                                Log.d(TAG, "add part");
                            }

                        } else {
                            Toast.makeText(getApplicationContext(),
                                    "Participant already linked to the event",
                                    Toast.LENGTH_SHORT).show();

                            Log.d(TAG, "Participant already exists");
                        }

                    } else {
                        Toast.makeText(getApplicationContext(),
                                "Please fill the email of the new participant",
                                Toast.LENGTH_SHORT).show();

                        Log.d(TAG, "No name to the new participant");
                    }

                }
            });

        } else {
            // user not logged in -> take him to the login activity
            Log.d(TAG, "User is not logged in");
            toLogin(ModifyEventActivity.this);
        }
    }

    /**
     * Check if the participant with the id can be safely removed from the event
     * if the participant is not the owner of the event or don't have any share in any
     * expenses of the event, he can be safely removed from the event.
     * @param id_part
     * @return
     */
    public boolean hasExpense(String id_part)
    {
        List<Expense> list_exp = event.getListExpenses();

        // for all the expenses of the event
        for (Expense exp: list_exp) {
            // check if participant is owner of the expense
            if (exp.getIdCreator() == id_part) {
                return true;
            }
            // if expense contains id of the participant
            if (exp.getIdPart().contains(id_part)) {
                // check if participant owns a share in this expense
                int pos = exp.getIdPart().indexOf(id_part);
                if (!exp.getSharePart().get(pos).equals("0")) {
                    return true;
                }
            }
        }
        return false;
    }

    public void update()
    {
        String name = modify_name.getText().toString().trim();
        String desc = modify_desc.getText().toString().trim();

        if (!name.isEmpty()) {
            event.setName(name);
            event.setDesc((desc.isEmpty()) ? "" : desc);
            event.setVersion(event.getVersion() + 1);
            event.setIdUsers(ev_list_ids);
            event.setEmailUsers(ev_list_emails);

            // update the list of participants of each expenses if necessary
            List<Expense> new_list_exp = new ArrayList<>();
            for (Expense exp: event.getListExpenses()) {
                Log.d(TAG, "exp before: " + exp.toString());
                // add new participants
                for (String part_id: event.getIdUsers()) {
                    if (!exp.getIdPart().contains(part_id)) {
                        // add the new id
                        exp.getIdPart().add(part_id);
                        // add the corresponding email
                        exp.getEmailPart().add(
                                event.getEmailUsers().get(
                                        event.getIdUsers().indexOf(part_id)
                                )
                        );
                        // add a '0' share
                        exp.getSharePart().add("0");
                    }
                }
                // remove participant
                for (String part_id: exp.getIdPart()) {
                    if (!event.getIdUsers().contains(part_id)) {
                        // index of the participant to remove
                        int index = exp.getIdPart().indexOf(part_id);
                        // remove the old id
                        exp.getIdPart().remove(index);
                        // remove the corresponding email
                        exp.getEmailPart().remove(index);
                        // add a '0' share
                        exp.getSharePart().remove(index);
                    }
                }
                Log.d(TAG, "exp after: " + exp.toString());
                new_list_exp.add(exp);
            }
            Log.d(TAG, "new list exp: " + new_list_exp.toString());

            // update the expenses of the event

            // TODO what to do if no connection available ?
            // sent the event to the server
            if (isNetworkAvailable()) { // if connection available
                VolleyRequest vr = new VolleyRequest(getApplicationContext());
                vr.eventToServer(event, user.getToken(), AppConfig.URL_UPDATE_EVENT, 0);
            } else {
                Log.d(TAG, "No connection to internet");
                Toast.makeText(getApplicationContext(),
                        "No connection to internet, couldn't store the event on the server",
                        Toast.LENGTH_SHORT).show();
            }

            // store the event in local database
            (new EventsDB(handler)).updateEvent(event);
            Log.d(TAG, "Event updated in local database: " + event.toString());

            Intent intent = new Intent();
            intent.putExtra("event", event);
            setResult(Activity.RESULT_OK, intent);
            finish();

        } else {
            Toast.makeText(getApplicationContext(),
                    "Please give a name to the event", Toast.LENGTH_LONG).show();
        }
    }


    /**
     * Check if the user has an account on the server database
     * @param email_user
     * @return
     */
    public void checkValidEmail(final String email_user) {
        HttpsTrustManager.allowAllSSL();

        // tag used to cancel the request
        String tag_string_req = "req_user_exists";

        pDialog.setMessage("Search for the user...");
        showDialog(pDialog);

        JSONObject jObj = null;
        try {
            jObj = new JSONObject("{\"email\":\"" + email_user + "\"}");

            String url = AppConfig.URL_USER_EXISTS;

            JsonObjectRequest jObjReq = new JsonObjectRequest(Request.Method.POST,
                    url, jObj, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                    Log.d(TAG, "Login Response: " + response.toString());
                    hideDialog(pDialog);

                    try {
                        boolean status = response.getBoolean("status");

                        // check the status of the answer in json
                        if (status) {
                            addParticipantToView(response.getString("id"), email_user);

                        } else {
                            Toast.makeText(getApplicationContext(),
                                    "This user doesn't have an account", Toast.LENGTH_LONG)
                                    .show();
                        }
                    } catch (JSONException e) {
                        // JSON error
                        e.printStackTrace();
                        Log.d(TAG, "JSON error " + e.getMessage());
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError errorV) {
                    Log.e(TAG, "Login volley request error: " + errorV.getMessage());
                    Toast.makeText(getApplicationContext(),
                            "Connection error, couldn't store the event on the server",
                            Toast.LENGTH_LONG).show();
                    hideDialog(pDialog);
                }
            });

            // Adding request to request queue
            AppController.getInstance().addToRequestQueue(jObjReq, tag_string_req);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    /**
     * add the new user to the view of the activity
     * @param id_user
     * @param email_user
     */
    public void addParticipantToView(String id_user, String email_user)
    {
        LinearLayout layout_show_part = (LinearLayout)
                findViewById(R.id.layout_list_participants);

        // create the views representing each participant to the event
        UserToView.addUserToView(this, email_user);
        LinearLayout l_part = UserToView.getLayoutUser();
        TextView email = UserToView.getEmailView();
        final ImageButton rm_part = UserToView.getRmButton();


/*        l_part.addView(email);
        l_part.addView(rm_part);*/

        l_list_part.addView(l_part);

        // add the views to a list of view in order to easily refer to them
        list_email_tv.add(email);
        list_rm_btn.add(rm_part);
        list_layout_users.add(l_part);

        // remove user of the event
        // if possible :
        // - the user must not be the creator of the event
        // - the user must not be a participant to an expense of the event
        rm_part.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // get the position of the user in the lists
                int i = list_rm_btn.indexOf(rm_part);

                String rm_id = event.getIdUsers().get(i);
                String rm_email = event.getEmailUsers().get(i);

                // check if the user is the creator of the event
                if (rm_id.equals(event.getIdCreator())) {
                    Toast.makeText(getApplicationContext(),
                            "Could not remove the owner of the event",
                            Toast.LENGTH_SHORT).show();
                }
                // check if the user participates to expenses
                else if (hasExpense(rm_id)) {
                    Toast.makeText(getApplicationContext(),
                            "Could not remove a participant who participates to an expense",
                            Toast.LENGTH_SHORT).show();
                } else { // if not, the user can be safely removed of the event
                    // remove the user from the view
                    /*((ViewManager) list_email_tv.get(list_rm_btn.indexOf(rm_part)).getParent()).
                            removeView(list_email_tv.get(list_rm_btn.indexOf(rm_part)));
                    ((ViewManager) rm_part.getParent()).removeView(rm_part);*/
                    // remove the layout from the view
                    ((ViewManager) list_layout_users.get(i).getParent()).
                            removeView(list_layout_users.get(i));

                    // remove the user from the event object
                    /*ev_list_ids.remove(rm_id);
                    ev_list_emails.remove(rm_email);
                    //event.removePart(rm_id, rm_email);
                    // remove the button from the list
                    list_rm_btn.remove(rm_part);*/

                    // remove the objects from the lists
                    list_layout_users.remove(i);
                    list_rm_btn.remove(i);
                    list_email_tv.remove(i);

                    // remove the user from the event object
                    ev_list_ids.remove(rm_id);
                    ev_list_emails.remove(rm_email);

                    Log.d(TAG, "listIds: " + ev_list_ids.toString()
                            + " - listEmails: " + ev_list_emails.toString());
                }

            }
        });

        // reset the text of the edittext
        name_part.setText("");

        // add the id and email to the list
        ev_list_ids.add(id_user);
        ev_list_emails.add(email_user);

        Log.d(TAG, "listIds: " + ev_list_ids.toString()
                + " - listEmails: " + ev_list_emails.toString());
    }
}
