package com.pion.app_login.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.github.clans.fab.FloatingActionButton;
import com.pion.app_login.Event;
import com.pion.app_login.Expense;
import com.pion.app_login.R;
import com.pion.app_login.app.AppConfig;
import com.pion.app_login.app.AppController;
import com.pion.app_login.app.HttpsTrustManager;
import com.pion.app_login.app.VolleyRequest;
import com.pion.app_login.database.EventsDB;
import com.pion.app_login.database.ExpenseDB;
import com.pion.app_login.database.UserDB;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// TODO: 27/01/16 propagate add/remove of a user to the expenses

// TODO: 25/01/16 check at the beginning the version of each event to know if down or up load
// TODO: 25/01/16 check at the end the version of each event to know if upload is required 
// TODO: 25/01/16 update event version when expense update
// TODO: 25/01/16 optimize results at the end

// TODO use of codes error (like 500, 401)

// TODO auto resend the data to the server (when false received or connection error...)

// TODO use of fragments and listViews
// TODO clean the code (use superclass, abstract...)

// TODO store the creation date of events and expenses and modification date

// TODO: 25/01/16 send a PDF, email at the end


/**
 * Main activity (first to be launched)
 * Show the events of the user
 * Download the events from the server
 * todo upload them if event stored on phone are updated
 * First activity to be launched
 * -> login activity if user not logged in
 * -> else load and show the events
 *
 * ------------------------------------------------------------------------------------
 * TUTORIALS
 * Activity life cycle
 *  http://developer.android.com/reference/android/app/Activity.html#ActivityLifecycle
 *
 * Fragments
 *  http://www.vogella.com/tutorials/AndroidFragments/article.html#fragments_tutorial
 *  https://github.com/codepath/android_guides/wiki/Creating-and-Using-Fragments
 *  http://mathias-seguy.developpez.com/cours/android/fragments/
 *
 * FAB (Floating Action Button)
 *  http://www.android4devs.com/2015/03/how-to-make-floating-action-button-fab.html
 *  http://blog.grafixartist.com/implement-floating-action-button-part-1/
 *  http://android-arsenal.com/details/1/1684
 *
 * Bar/ActionBar
 *  http://www.android4devs.com/2014/12/how-to-make-material-design-app.html
 *
 * Add external libraries
 *  http://stackoverflow.com/questions/16588064/how-do-i-add-a-library-project-to-the-android-studio
 *
 * Icons
 *  https://design.google.com/icons/index.html
 *
 * List Views
 *  http://www.vogella.com/tutorials/AndroidListView/article.html
 *----------------------------------------------------------------------------------
 *
 * <br><br>
 *
 * Created by <i>pion</i> on 01/12/15.
 */
public class EventsActivity extends AppActivity {
    private static String TAG = EventsActivity.class.getSimpleName();

    private Toolbar toolbar;
    private FloatingActionButton fab;

    private LinearLayout layout_events;

    /**
     * Map between the id of an event and the event
     * contains all the event stored on the phone
     * events on there latest version known
     */
    private Map<String, Event> local_events;
    /**
     * map the id and the version of an event
     */
    private Map<String, Integer> map_id_to_version;
    /**
     * map the id and the button of an event
     */
    private Map<String, Button> map_id_to_button;

    private String id_user;

    private VolleyRequest vr;

    static final int INT_CREATE_EVENT = 1; // the request code to create an event
    static final int INT_SHOW_EVENT = 2; // the request code to show an event

    @Override
    public void onCreate(Bundle savedInstancesState)
    {
        super.onCreate(savedInstancesState);
        setContentView(R.layout.events);
        Log.d(TAG, "EventsActivity launched");

        // toolbar
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // layout where the events are shown
        layout_events = (LinearLayout) findViewById(R.id.show_events);

        // instantiate all other attributes
        local_events = new HashMap<>();
        map_id_to_version = new HashMap<>();
        map_id_to_button = new HashMap<>();

        vr = new VolleyRequest(getApplicationContext());

        // check if user already logged in or not
        if (session.isLoggedIn()) {
            Log.d(TAG, "User is logged in");


            if (user.getId() != null) {
                Log.d(TAG, "User fetched from the local database");

                id_user = user.getId();
                Log.d(TAG, "id_user: " + id_user);

                if (isNetworkAvailable()) {
                    Log.d(TAG, "Network ok");
                    // load server events and store them in local database
                    loadServerEvents();
                } else {
                    // TODO: 25/01/16 store boolean to know if event downloaded or not
                    loadLocalEvents();
                }

                // Floating Action Button - add an event
                fab = (FloatingActionButton) findViewById(R.id.fab_add_event);
                fab.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        // Switching to create event activity
                        Intent intent = new Intent(EventsActivity.this, CreateEventActivity.class);
                        startActivityForResult(intent, INT_CREATE_EVENT);
                        onStop(); // new activity launched => EventsActivity is put in background
                    }
                });

            } else {
                Log.d(TAG, "Not able to fetch the user inside the local database");
            }
        } else {
            // user not logged in -> take him to the login activity
            Log.d(TAG, "User is not logged in");
            toLogin(EventsActivity.this);
        }
    }

    // TOOLBAR
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_events, menu);
        return true;
    }

    // action bar item click
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_refresh) {
            if (isNetworkAvailable()) {
                Log.d(TAG, "Network ok");
                // load server events and store them in local database
                loadServerEvents();
            } else {
                // TODO: 26/01/16 if no connection, load local event when refresh ??
                Toast.makeText(this, "Phone currently offline, internet is required for sync", Toast.LENGTH_LONG).show();
            }
        } else if (id == R.id.action_logout) {
            logoutUser();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onRestart()
    {
        super.onRestart();
        // reload the events in order to apply the eventual modifications
        loadLocalEvents();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d(TAG, "Launch onActivityResult");
        // if request from the modify activity
        if (requestCode == INT_CREATE_EVENT) {
            // Result after event creation
            if (resultCode == RESULT_OK) { // make sure the request was successful
                Log.d(TAG, "On result after event creation");
                // Update the event
                Event new_event = (Event) data.getSerializableExtra("event");

                // add the new event to the list
                local_events.put(new_event.getId(), new_event);

                // add a button for this event
                addButton(new_event);

                //updateView();

                Log.d(TAG, "New event created: " + new_event.toString());
            }
        }
        // if request from the show activity
        else if (requestCode == INT_SHOW_EVENT) {
            // Result after event creation
            if (resultCode == RESULT_OK) { // make sure the request was successful
                Log.d(TAG, "On result after show event");
                // Update the event
                Event updated_event = (Event) data.getSerializableExtra("event");

                // modify the event in the list
                local_events.put(updated_event.getId(), updated_event);

                // update the button for this event
                Button button = map_id_to_button.get(updated_event.getId());
                button.setText(updated_event.getName());
                map_id_to_button.put(updated_event.getId(), button);

                //updateView();

                Log.d(TAG, "Event updated in list: " + updated_event.toString());
            }
        }
    }

    /**
     * Load the events of the user from the server <br>
     * Store <i>events</i> and <i>expenses</i> downloaded on phone database
     */
    public void loadServerEvents()
    {
        // accept all the contracts
        HttpsTrustManager.allowAllSSL();

        // tag used to cancel the request
        String tag_string_req = "req_load_events";

        pDialog.setMessage("Synchronizing the event...");
        showDialog(pDialog);

        // store the id of the received events
        final List<String> received_ev_ids = new ArrayList<>();

        // json sent to server
        String json = "{\"token\":\"" + user.getToken() + "\"}";

        Log.d(TAG, "Json send: " + json);

        JSONObject jObj = null;
        try {
            jObj = new JSONObject(json);

            // url of the request on server
            String url = AppConfig.URL_LOAD_EVENTS;

            JsonObjectRequest jObjReq = new JsonObjectRequest(Request.Method.POST,
                    url , jObj, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                    Log.d(TAG, "LoadEvents response: " + response.toString());

                    try {
                        boolean status = response.getBoolean("status");

                        // check the status of the answer in json
                        if (status) {
                            EventsDB eventDB = new EventsDB(handler);
                            ExpenseDB expenseDB = new ExpenseDB(handler);

                            // extract all the events
                            // read the interface file to see how to parse the json
                            JSONArray eventsJArr = response.getJSONArray("eventList");
                            for (int i=0; i < eventsJArr.length(); i++) {
                                // extract each object of the array of events
                                JSONObject eventJObj = eventsJArr.getJSONObject(i);

                                Event event = new Event();

                                String id = eventJObj.getString("id");
                                event.setId(id);
                                received_ev_ids.add(id); //add the id to the list
                                //int version = Integer.parseInt(eventJObj.getString("version"));
                                int version = 0;
                                event.setVersion(version);

                                // continue to parse the JSON file if the id of the event
                                // is not already a key of the map id_to_version
                                // OR if the version of the loaded event is greater than
                                // the version already stored in the map
                                if (!map_id_to_version.containsKey(id) ||
                                        ( version > map_id_to_version.get(id) ) ) {
                                    event.setName(eventJObj.getString("name"));
                                    event.setDesc(eventJObj.getString("description"));
                                    event.setIdCreator(eventJObj.getString("creatorId"));
                                    event.setCreatedAt(getDateTime());

                                    JSONArray usersJArr = eventJObj.getJSONArray("users");
                                    List<String> ids = new ArrayList<>();
                                    List<String> emails = new ArrayList<>();
                                    for (int j=0; j < usersJArr.length(); j++) {
                                        // extract each object of the array of users
                                        JSONObject userJObj = usersJArr.getJSONObject(j);
                                        ids.add(userJObj.getString("id"));
                                        emails.add(userJObj.getString("email"));
                                    }

                                    event.setIdUsers(ids);
                                    event.setEmailUsers(emails);

                                    JSONArray expJArr = eventJObj.getJSONArray("expenses");
                                    // if expenses is not empty
                                    Log.d(TAG, "nbr expenses: " + expJArr.length());
                                    if (expJArr.length() > 0) {
                                        List<Expense> l_exp = new ArrayList<>();
                                        for (int j = 0; j < expJArr.length(); j++) {
                                            // extract each object of the array of expenses
                                            JSONObject expJObj = expJArr.getJSONObject(j);

                                            Expense expense = new Expense();
                                            expense.setId(expJObj.getString("id"));
                                            expense.setIdEvent(event.getId());
                                            expense.setName(expJObj.getString("name"));
                                            expense.setType(expJObj.getString("type"));
                                            expense.setAmount(expJObj.getString("amount"));
                                            expense.setIdCreator(expJObj.getString("creatorId"));
                                            expense.setVersion(Integer.parseInt(
                                                    expJObj.getString("version")));
                                            expense.setCreatedAt(""); // TODO: 25/01/16 store the creation date

                                            JSONArray sharesJArr = expJObj.getJSONArray("shares");
                                            List<String> id_parts = new ArrayList<>();
                                            List<String> email_parts = new ArrayList<>();
                                            List<String> share_parts = new ArrayList<>();
                                            for (int k = 0; k < sharesJArr.length(); k++) {
                                                // extract each object of the array of shares
                                                JSONObject share = sharesJArr.getJSONObject(k);
                                                String s_id = share.getString("id");
                                                id_parts.add(s_id);
                                                email_parts.add(emails.get(ids.indexOf(s_id)));
                                                share_parts.add(share.getString("share"));
                                            }
                                            expense.setIdPart(id_parts);
                                            expense.setEmailPart(email_parts);
                                            expense.setSharePart(share_parts);

                                            // store the expense in local database
                                            expenseDB.addExpense(expense);
                                            Log.d(TAG, "expense add to database: " + expense.toString());

                                            l_exp.add(expense);
                                        }

                                        event.setListExpenses(l_exp); // bind expenses to the event
                                    } else {
                                        event.setListExpenses(new ArrayList<Expense>());
                                    }
                                    Log.d(TAG, "nbr: " + event.nbrExp());

                                    // store the event in local database
                                    eventDB.addEvent(event);

                                    Log.d(TAG, "event " + i + " loaded: " + event.toString());

                                } else {
                                    Event event_loc = local_events.get(id);
                                    if (event_loc != null) {
                                        // if event stored on phone has newer version
                                        // then upload it and its expenses
                                        if (version < event_loc.getVersion()) {
                                            uploadServer(event_loc, null, 1);

                                            // get the downloaded expenses
                                            Map<String, Integer> down_exp_ids_to_version = new HashMap<>();
                                            JSONArray expJArr = eventJObj.getJSONArray("expenses");
                                            // if expenses is not leer
                                            if (expJArr.length() > 1) {
                                                for (int j = 0; j < expJArr.length(); j++) {
                                                    // extract ids and version of each expense
                                                    JSONObject expJObj = expJArr.getJSONObject(j);

                                                    down_exp_ids_to_version.put(
                                                            expJObj.getString("id"),
                                                            Integer.parseInt(expJObj.getString("version")));
                                                }
                                            }

                                            // check its expenses
                                            for (Expense exp : event_loc.getListExpenses()) {
                                                // if the expense already exists
                                                // update if newer version on the phone
                                                if (down_exp_ids_to_version.containsKey(exp.getId())) {
                                                    if (exp.getVersion() > down_exp_ids_to_version.get(exp.getId())) {
                                                        uploadServer(null, exp, 1);
                                                    }
                                                } else {
                                                    uploadServer(null, exp, 0);
                                                }
                                            }

                                            Log.d(TAG, "event " + i + " has an older version on the phone" +
                                                    "(update sent to server): " + local_events.get(id).toString());
                                        }
                                    } else {
                                        Log.d(TAG, "event " + i + " version : " + version + " - local version: " + local_events.get(id).getVersion());
                                        Log.d(TAG, "event " + i + " not loaded (already exists): " + local_events.get(id).toString());
                                    }
                                }

                            }

                            // check for new local event not stored on server
                            for (String id_ev: local_events.keySet()) {
                                // if the id of the local event was not received
                                // then the local event is new and has to be uploaded to the server
                                if (!received_ev_ids.contains(id_ev)) {
                                    Event ev = local_events.get(id_ev);
                                    Log.d(TAG, "event doesn't exists on server: " + ev.toString());
                                    uploadServer(ev, null, 0);
                                    // upload its expenses for creation on server side
                                    for (Expense exp: ev.getListExpenses()) {
                                        uploadServer(null, exp, 0);
                                    }
                                }
                            }

                            // at the end of the request, show the events
                            loadLocalEvents();

                            Log.d(TAG, "Events loaded");
                        } else {
                            // error occurred in creation of the event on the server
                            Log.d(TAG, "Error loading of the events from the server");
                        }
                    } catch (JSONException e) {
                        // JSON error
                        e.printStackTrace();
                        Log.d(TAG, "JSON error " + e.getMessage());
                    }

                    hideDialog(pDialog);
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError errorV) {
                    Log.e(TAG, "LoadEvents volley request error: " + errorV.getMessage());
                    Toast.makeText(getApplicationContext(),
                            "Connection error, try again", Toast.LENGTH_LONG).show();
                    hideDialog(pDialog);
                }
            });

            // Adding request to request queue
            AppController.getInstance().addToRequestQueue(jObjReq, tag_string_req);

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    /**
     * Get the events of the user from the phone database
     * and call a method to display them on the activity
     */
    public void loadLocalEvents()
    {
        Log.d(TAG, "Fetching the events of the user: " + id_user + " from the local database");

        EventsDB eventsDB = new EventsDB(handler);
        List<Event> list_events = eventsDB.getEvents(id_user);

        for (Event event: list_events) {
            String id_event = event.getId();
            // add or update the events in the map
            local_events.put(id_event, event);

            // add a button for an event
            // if not possess already a button
            if (!map_id_to_button.containsKey(id_event)) {
                addButton(event);
            } else {
                // already possess a button, then update it if newer version
                if (event.getVersion() > map_id_to_version.get(id_event)) {
                    Button button = map_id_to_button.get(id_event);
                    button.setText(event.getName());
                    // and update the button in the map
                    map_id_to_button.put(id_event, button);
                    // and its version
                    map_id_to_version.put(id_event, event.getVersion());
                }
            }
        }
    }

    /**
     * Upload the data to the server
     * @param event event to upload
     * @param expense expense to upload
     * @param flag 0 to create, 1 to update
     */
    public void uploadServer(Event event, Expense expense, int flag) {
        if (flag == 1) { // update on the server
            // update event
            if (event != null) {
                vr.eventToServer(
                        event,
                        user.getToken(),
                        AppConfig.URL_UPDATE_EVENT,
                        0);
                Log.d(TAG, "Upload event for update: " + event.toString());
            }
            // update expenses
            if (expense != null) {
                vr.expenseToServer(
                        expense,
                        user.getToken(),
                        AppConfig.URL_UPDATE_EXPENSE,
                        0);
                Log.d(TAG, "Upload expense for update: " + expense.toString());
            }
        } else if (flag == 0) { // create on server
            // create event
            if (event != null) {
                vr.eventToServer(
                        event,
                        user.getToken(),
                        AppConfig.URL_CREATE_EVENT,
                        0);
                Log.d(TAG, "Upload event for creation: " + event.toString());
            }
            // create expenses
            if (expense != null) {
                vr.expenseToServer(
                        expense,
                        user.getToken(),
                        AppConfig.URL_CREATE_EXPENSE,
                        0);
                Log.d(TAG, "Upload expense for creation: " + expense.toString());
            }
        }
    }

    /**
     * Add a button for en event to the view and link it to the ShowEventActivity
     * with the event in extra
     * @param event to add to the view
     */
    public void addButton(final Event event)
    {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int height = (int) (TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 80, dm));
        int top = (int) (TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 25, dm));
        int txt_size = (int) (TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 30, dm));


        Button button = new Button(this);
        button.setHeight(height);
        button.setTop(top);
        button.setText(event.getName());
        //button.setTextColor();
        layout_events.addView(button);

        // on click start the new activity
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "open eventViewActivity...");

                goToShowEvent(event.getId());
            }
        });

        // store the button in the map with the id_event as key
        map_id_to_button.put(event.getId(), button);
        // and store its version
        map_id_to_version.put(event.getId(), event.getVersion());
    }

    /**
     * This method allows to send the last version of an event
     * When called, will start a ShowEventActivity and put the event
     * with the id in parameter as extra to the intent
     * @param id_event id of the event to send to the next activity
     */
    public void goToShowEvent(String id_event)
    {
        Intent intent = new Intent(EventsActivity.this, ShowEventActivity.class);
        intent.putExtra("event", local_events.get(id_event));
        startActivity(intent);
        onPause();
    }

    /**
     * Logging out the user <br>
     * Will set the flag isLoggedIn to false <br>
     * And clear the user data from SQLite users table (phone database)
     */
    private void logoutUser()
    {
        session.setLogin(false);

        (new UserDB(handler)).deleteUser();

        // launching the login activity
        Intent intent = new Intent(EventsActivity.this,
                LoginActivity.class);
        startActivity(intent);
        finish();
    }
}
