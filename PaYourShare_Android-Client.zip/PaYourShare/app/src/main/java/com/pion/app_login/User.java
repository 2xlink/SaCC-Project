package com.pion.app_login;

/**
 * User object (attributes and key values are the same)
 *
 * Created by pion on 02/12/15.
 */
public class User {

    private String id;
    private String token;
    private String name;
    private String email;
    private String created_at;

    public User()
    {
        this.id = null;
        this.token = null;
        this.name = null;
        this.email = null;
        this.created_at = null;
    }

    public User(String id, String email)
    {
        this.id = id;
        this.email = email;
        this.token = null;
        this.name = null;
        this.created_at = null;
    }

    public User(String id, String token, String name, String email, String created_at)
    {
        this.id = id;
        this.token = token;
        this.name = name;
        this.email = email;
        this.created_at = created_at;
    }

    public User(String id, String token, String name, String email)
    {
        this.id = id;
        this.token = token;
        this.name = name;
        this.email = email;
        this.created_at = null;
    }


    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getToken() { return token; }
    public void setToken(String token) { this.token = token; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getCreatedAt() { return created_at; }
    public void setCreatedAt(String created_at) { this.created_at = created_at; }

    public String toString() {
        return "id: " + this.id + " - name: " + this.name + " - email: " + this.email
                + " - created_at: " + this.created_at;
    }
}
