package com.pion.app_login.app;

/**
 * File to config the server access
 * and the path to the REST request
 *
 * Created by pion on 30/11/15.
 */
public class AppConfig {
    // database path
    public static final String DATABASE_PATH = "//data/data/com.pion.app_login/databases/";
    // database name
    public static final String DATABASE_NAME = "android_api";

    // =======================================================================
    // SECTION TO CHANGE FOR A PERSONAL USE (SERVER IP AND PORT)

    // server url
    private static final String URL_SERVER = "10.100.33.13";
    // server port
    private static final String PORT_SERVER = "8443";

    // END SECTION TO CHANGE
    // =======================================================================

    // Urls to access the Tomcat server
    public static final String URL_LOGIN = "https://" + URL_SERVER + ":" + PORT_SERVER
            + "/server/rest/user/login";
    public static final String URL_REGISTER = "https://" + URL_SERVER + ":" + PORT_SERVER
            + "/server/rest/user/register";
    public static final String URL_USER_EXISTS = "https://" + URL_SERVER + ":" + PORT_SERVER
            + "/server/rest/user/exists";
    public static final String URL_LOAD_EVENTS = "https://" + URL_SERVER + ":" + PORT_SERVER
            + "/server/rest/user/getEvents/";
    public static final String URL_CREATE_EVENT = "https://"+ URL_SERVER + ":" + PORT_SERVER
            + "/server/rest/event/create";
    public static final String URL_UPDATE_EVENT = "https://"+ URL_SERVER + ":" + PORT_SERVER
            + "/server/rest/event/update";
    public static final String URL_UPDATE_EXPENSE = "https://" + URL_SERVER + ":" + PORT_SERVER
            + "/server/rest/expense/update";
    public static final String URL_CREATE_EXPENSE = "https://" + URL_SERVER + ":" + PORT_SERVER
            + "/server/rest/expense/create";


    // other server for tests
/*
    public static final String URL_LOGIN = "http://" + URL_SERVER + "/server2/login.php";
    public static final String URL_REGISTER = "http://" + URL_SERVER + "/server2/register.php";
    public static final String URL_USER_EXISTS = "http://" + URL_SERVER + "/server2/user_exists.php";
    public static final String URL_LOAD_EVENTS = "http://" + URL_SERVER + "/server2/load_events.php";
    public static final String URL_CREATE_EVENT = "http://" + URL_SERVER + "/server2/create_event.php";
    public static final String URL_UPDATE_EVENT = "http://" + URL_SERVER + "/server2/update_event.php";
    public static final String URL_CREATE_EXPENSE = "http://" + URL_SERVER + "/server2/create_expense.php";
    public static final String URL_UPDATE_EXPENSE = "http://" + URL_SERVER + "/server2/update_expense.php";
*/

}
