package com.pion.app_login.activities;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.pion.app_login.R;
import com.pion.app_login.User;
import com.pion.app_login.app.AppConfig;
import com.pion.app_login.app.AppController;
import com.pion.app_login.app.HttpsTrustManager;
import com.pion.app_login.database.SQLiteHandler;
import com.pion.app_login.database.SessionManager;
import com.pion.app_login.database.UserDB;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Created by pion on 30/11/15.
 */
public class RegisterActivity extends Activity {
    public static final String TAG = RegisterActivity.class.getSimpleName();

    private Button btnRegister;
    private Button btnLinkToLogin;
    private EditText inputFullName;
    private EditText inputEmail;
    private EditText inputPassword;

    private ProgressDialog pDialog;

    private SessionManager session;

    private SQLiteHandler handler;

    //private UserDB userDb;

    @Override
    public void onCreate(Bundle savedInstancesState)
    {
        super.onCreate(savedInstancesState);
        // set view to register.xml
        setContentView(R.layout.register);

        inputFullName = (EditText) findViewById(R.id.reg_fullname);
        inputEmail = (EditText) findViewById(R.id.reg_email);
        inputPassword = (EditText) findViewById(R.id.reg_password);
        btnRegister = (Button) findViewById(R.id.btnRegister);
        btnLinkToLogin = (Button) findViewById(R.id.link_to_login);

        // Progress Dialog
        pDialog = new ProgressDialog(this);
        pDialog.setCancelable(false);

        // session manager
        session = new SessionManager(getApplicationContext());

        // SQLite handler of database
        handler = new SQLiteHandler(getApplicationContext());

        // check if user already logged in or not
        if (session.isLoggedIn()) {
            // user already logged in -> take him to the main activity
            Intent intent = new Intent(RegisterActivity.this, EventsActivity.class);
            startActivity(intent);
            finish();
        }

        // Register button click event
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = inputFullName.getText().toString().trim();
                String email = inputEmail.getText().toString().trim();
                String password = inputPassword.getText().toString().trim();

                if (!name.isEmpty() && !email.isEmpty() && !password.isEmpty()) {
                    String id = UUID.randomUUID().toString();
                    registerUser(id, name, email, password);
                } else {
                    Toast.makeText(getApplicationContext(),
                            "Please fill the fields", Toast.LENGTH_LONG).show();
                }
            }
        });

        // Listening to register new account link
        btnLinkToLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                // switching to Login screen / closing register screen
                finish();
            }
        });
    }

    /**
     * Function to store user in MySQL database
     * @params name, email, password
     */
    private void registerUser(final String id, final String name, final String email, final String password)
    {
        HttpsTrustManager.allowAllSSL();

        // tag used to cancel the request
        String tag_string_req = "req_register";

        pDialog.setMessage("Registering...");
        showDialog();

        JSONObject jObj = null;
        try {
            jObj = new JSONObject("{"
                    + "\"id\":\"" + id + "\","
                    + "\"email\":\"" + email + "\","
                    + "\"password\":\"" + password + "\"}");

            String url = AppConfig.URL_REGISTER;

            JsonObjectRequest jObjReq = new JsonObjectRequest(Request.Method.POST,
                    url , jObj, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                    Log.d(TAG, "Login Response: " + response.toString());
                    hideDialog();

                    try {
                        String status = response.getString("status");

                        // check the status of the answer in json
                        if (status.equals("true") || status.equals("TRUE") || status.equals("True")) {
                            // user successfully logged in
                            // create login session
                            session.setLogin(true);

                            // now store the user in SQLite
                           // String id = response.getString("id");
                            String token = response.getString("token");

                            // inserting row in users table
                            (new UserDB(handler)).addUser(new User(id, token, null, email));

                            // launch event activity
                            Intent intent = new Intent(RegisterActivity.this,
                                    EventsActivity.class);
                            startActivity(intent);
                            finish();
                        } else {
                            // error in login
                            // TODO: show an explicit message in case of error
                            Toast.makeText(getApplicationContext(),
                                    "Registration failed, try again", Toast.LENGTH_LONG).show();
                        }
                    } catch (JSONException e) {
                        // JSON error
                        e.printStackTrace();
                        Log.d(TAG, "JSON error " + e.getMessage());
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError errorV) {
                    Log.e(TAG, "Login volley request error: " + errorV.getMessage());
                    Toast.makeText(getApplicationContext(),
                            "Connection error, try again", Toast.LENGTH_LONG).show();
                    hideDialog();
                }
            });

            // Adding request to request queue
            AppController.getInstance().addToRequestQueue(jObjReq, tag_string_req);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
    
    private void showDialog()
    {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    private void hideDialog()
    {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }
}

