package com.pion.app_login.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.pion.app_login.app.AppConfig;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Interact with the database of the phone SQLite
 *
 * Created by pion on 02/12/15.
 */
public class SQLiteHandler  extends SQLiteOpenHelper implements Serializable {
    private static final String TAG = SQLiteHandler.class.getSimpleName();

    // Database version
    private static final int DATABASE_VERSION = 1;
    // Database Name
    private static final String DATABASE_NAME = AppConfig.DATABASE_NAME;


    // tables name
    public static final String TABLE_USER = "user";
    public static final String TABLE_EVENTS = "events";
    public static final String TABLE_EXPENSES = "expenses";

    // user table columns name
    public static final String KEY_USER_ID_TABLE = "id";
    public static final String KEY_USER_ID = "id_user";
    public static final String KEY_USER_TOKEN = "token_user";
    public static final String KEY_USER_NAME = "name";
    public static final String KEY_USER_EMAIL = "email";
    public static final String KEY_USER_CREATED_AT = "created_at";

    // events table columns name
    public static final String KEY_EVENTS_ID_TABLE = "id";
    public static final String KEY_EVENTS_ID = "id_event";
    public static final String KEY_EVENTS_NAME = "name";
    public static final String KEY_EVENTS_DESC = "desc";
    public static final String KEY_EVENTS_ID_CREATOR = "id_creator";
    public static final String KEY_EVENTS_ID_PARTICIPANT = "id_participant";
    public static final String KEY_EVENTS_EMAIL_PARTICIPANT = "email_participant";
    public static final String KEY_EVENTS_ID_LIST_OF_USERS = "id_list_of_users";
    public static final String KEY_EVENT_VERSION = "version";
    public static final String KEY_EVENTS_CREATED_AT = "created_at";

    // expense table columns name
    public static final String KEY_EXPENSE_ID_TABLE = "id";
    public static final String KEY_EXPENSE_ID = "id_expense";
    public static final String KEY_EXPENSE_ID_EVENT = "id_event";
    public static final String KEY_EXPENSE_NAME = "name";
    public static final String KEY_EXPENSE_AMOUNT = "value";
    public static final String KEY_EXPENSE_TYPE = "type";
    public static final String KEY_EXPENSE_ID_CREATOR = "id_creator";
    public static final String KEY_EXPENSE_ID_PARTICIPANT = "id_participant";
    public static final String KEY_EXPENSE_EMAIL_PARTICIPANT = "email_participant";
    public static final String KEY_EXPENSE_SHARE = "share";
    public static final String KEY_EXPENSE_VERSION = "version";
    public static final String KEY_EXPENSE_CREATED_AT = "created_at";


    public SQLiteHandler(Context context)
    {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Creating Tables
    @Override
    public void onCreate(SQLiteDatabase db)
    {
        // TODO keys not null or not ?? think about it
        String CREATE_USER_TABLE = "CREATE TABLE IF NOT EXISTS " + TABLE_USER + "("
                + KEY_USER_ID_TABLE + " INTEGER PRIMARY KEY,"
                + KEY_USER_ID + " TEXT,"
                + KEY_USER_TOKEN + " TEXT,"
                + KEY_USER_NAME + " TEXT,"
                + KEY_USER_EMAIL + " TEXT UNIQUE,"
                + KEY_USER_CREATED_AT + " TEXT" + ");";
        db.execSQL(CREATE_USER_TABLE);

        String CREATE_EVENTS_TABLE = "CREATE TABLE IF NOT EXISTS " + TABLE_EVENTS + "("
                + KEY_EVENTS_ID_TABLE + " INTEGER PRIMARY KEY,"
                + KEY_EVENTS_ID + " TEXT,"
                + KEY_EVENTS_NAME + " TEXT NOT NULL,"
                + KEY_EVENTS_DESC + " TEXT, "
                + KEY_EVENTS_ID_CREATOR + " TEXT,"
                + KEY_EVENTS_ID_PARTICIPANT + " TEXT,"
                + KEY_EVENTS_EMAIL_PARTICIPANT + " TEXT,"
                + KEY_EVENTS_ID_LIST_OF_USERS + " TEXT,"
                + KEY_EVENT_VERSION + " TEXT,"
                + KEY_EVENTS_CREATED_AT + " TEXT" + ");";
        db.execSQL(CREATE_EVENTS_TABLE);

        String CREATE_EXPENSE_TABLE = "CREATE TABLE IF NOT EXISTS " + TABLE_EXPENSES + "("
                + KEY_EXPENSE_ID_TABLE + " INTEGER PRIMARY KEY,"
                + KEY_EXPENSE_ID + " TEXT,"
                + KEY_EXPENSE_ID_EVENT + " TEXT,"
                + KEY_EXPENSE_NAME + " TEXT NOT NULL,"
                + KEY_EXPENSE_AMOUNT + " TEXT NOT NULL,"
                + KEY_EXPENSE_TYPE + " TEXT,"
                + KEY_EXPENSE_ID_CREATOR + " TEXT,"
                + KEY_EXPENSE_ID_PARTICIPANT + " TEXT,"
                + KEY_EXPENSE_EMAIL_PARTICIPANT + " TEXT,"
                + KEY_EXPENSE_SHARE + " TEXT,"
                + KEY_EXPENSE_VERSION + " TEXT,"
                + KEY_EXPENSE_CREATED_AT + " TEXT" + ");";
        db.execSQL(CREATE_EXPENSE_TABLE);

        Log.d(TAG, "Database tables created");
    }

    // Upgrading database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        // Drop older tables if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER + " " + TABLE_EVENTS);

        // Create tables again
        onCreate(db);
    }

    
    /**
     * get datetime
     **/
    protected static String getDateTime() {
        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        Date date = new Date();
        return dateFormat.format(date);
    }

}
