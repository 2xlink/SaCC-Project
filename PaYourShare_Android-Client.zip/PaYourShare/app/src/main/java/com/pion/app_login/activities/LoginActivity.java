package com.pion.app_login.activities;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.pion.app_login.R;
import com.pion.app_login.User;
import com.pion.app_login.app.AppConfig;
import com.pion.app_login.app.AppController;
import com.pion.app_login.app.HttpsTrustManager;
import com.pion.app_login.database.SQLiteHandler;
import com.pion.app_login.database.SessionManager;
import com.pion.app_login.database.UserDB;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Activity for the login of a user
 *
 * Created by pion on 30/11/15.
 */

public class LoginActivity extends AppActivity {
    private static final String TAG = LoginActivity.class.getSimpleName();

    private Button btnLogin;
    private Button btnLinkToRegister;
    private EditText inputEmail;
    private EditText inputPassword;

    @Override
    public void onCreate(Bundle savedInstancesState)
    {
        super.onCreate(savedInstancesState);
        // setting default scree to login.xml
        setContentView(R.layout.login);

        inputEmail = (EditText) findViewById(R.id.log_email);
        inputPassword = (EditText) findViewById(R.id.log_password);
        btnLogin = (Button) findViewById(R.id.btnLogin);
        btnLinkToRegister = (Button) findViewById(R.id.link_to_register);

        // check if user is already logged in or not
        if (session.isLoggedIn()) {
            // user is already logged in -> take him to the main activity
            Log.d(TAG, "User is not logged in");
            toLogin(LoginActivity.this);
        }

        // login button click event
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = inputEmail.getText().toString().trim();
                String password = inputPassword.getText().toString().trim();

                // check for empty data in the form
                if (!email.isEmpty() && !password.isEmpty()) {
                    checkLogin(email, password);
                } else {
                    // prompt user to enter datas
                    Toast.makeText(getApplicationContext(),
                            "Please fill the fields", Toast.LENGTH_LONG).show();
                }
            }
        });

        // Listening to register new account link
        btnLinkToRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Switching to Register screen
                Intent i = new Intent(getApplicationContext(), RegisterActivity.class);
                startActivity(i);
            }
        });
    }

    /**
     * Function to verify login details in mysql db
     * @param email
     * @param password
     */
    private void checkLogin(final String email, final String password)
    {
        HttpsTrustManager.allowAllSSL();

        // Tag used to cancel the request
        String tag_string_req = "req_login";

        pDialog.setMessage("Logging in...");
        showDialog();

        JSONObject jObj = null;
        try {
            jObj = new JSONObject("{\"email\":\"" + email + "\"," +
                    "\"password\":\"" + password + "\"}");

            String url = AppConfig.URL_LOGIN;

            JsonObjectRequest jObjReq = new JsonObjectRequest(Request.Method.POST,
                    url , jObj, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                    Log.d(TAG, "Login Response: " + response.toString());
                    hideDialog();

                    try {
                        boolean status = response.getBoolean("status");

                        // check the status of the answer in json
                        if (status) {
                            // user successfully logged in
                            // create login session
                            session.setLogin(true);

                            // now store the user in SQLite
                            String id = response.getString("id");
                            String token = response.getString("token");

                            // inserting row in users table
                            (new UserDB(handler)).addUser(new User(id, token, null, email));

                            // launch event activity
                            Intent intent = new Intent(LoginActivity.this,
                                    EventsActivity.class);
                            startActivity(intent);
                            finish();
                        } else {
                            // error in login
                            // TODO: show an explicit error
                            Toast.makeText(getApplicationContext(),
                                    "Email and password don't match",
                                    Toast.LENGTH_LONG).show();
                        }
                    } catch (JSONException e) {
                        // JSON error
                        e.printStackTrace();
                        Log.d(TAG, "JSON error " + e.getMessage());
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError errorV) {
                    Log.e(TAG, "Login volley request error: " + errorV.getMessage());
                    Toast.makeText(getApplicationContext(),
                            "Connection error, try again", Toast.LENGTH_LONG).show();
                    hideDialog();
                }
            });

            // Adding request to request queue
            AppController.getInstance().addToRequestQueue(jObjReq, tag_string_req);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    private void showDialog()
    {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    private void hideDialog()
    {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }

}
