package com.pion.app_login.activities;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.pion.app_login.Expense;
import com.pion.app_login.R;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by pion on 14/12/15.
 */
public class ShowExpenseActivity extends ShowActivity {
    public static String TAG = ShowExpenseActivity.class.getSimpleName();

    private Toolbar toolbar;
    private ActionBar supportActionBar;

    private TextView exp_amount;
    private TextView exp_type;
    private TextView exp_creator;
    private LinearLayout layout_participants;

    private List<TextView> exp_list_share_text_view;

    private Expense expense;

    static final int INT_MODIFY_EXPENSE = 1; // the request code to modify an expense

    @Override
    public void onCreate(Bundle savedInstancesState)
    {
        super.onCreate(savedInstancesState);
        setContentView(R.layout.show_expense);
        Log.d(TAG, "ShowExpenseActivity launched");

        // toolbar
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        // add a return button to go to the previous activity
        supportActionBar = getSupportActionBar();
        supportActionBar.setDisplayHomeAsUpEnabled(true);

        // objects of the view
        exp_amount = (TextView) findViewById(R.id.show_expense_value);
        exp_type = (TextView) findViewById(R.id.show_expense_type);
        exp_creator = (TextView) findViewById(R.id.show_expense_creator);

        exp_list_share_text_view = new ArrayList<>();

        // if user is logged in
        if (session.isLoggedIn()) {
            Log.d(TAG, "User is logged in");

            expense = (Expense) getIntent().getSerializableExtra("expense");
            /*int id_exp = getIntent().getIntExtra("id_exp", 0);
            expense = event.getListExpenses().get(id_exp);*/


            /*fab = (FloatingActionButton) findViewById(R.id.fab_modif_exp);
            fab.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(ShowExpenseActivity.this, ModifyExpenseActivity.class);
                    intent.putExtra("expense", expense);
                    startActivityForResult(intent, INT_MODIFY_EXPENSE);
                    onStop();
                }
            });*/

            layout_participants = (LinearLayout) findViewById(R.id.show_participants);

            String value = expense.getAmount() + " €";
            String type = (expense.getType() == null || expense.getType() == "") ? "" :
                    "Type: " + expense.getType();
            String created_by = "Paid by " + getEmailFromId(expense.getIdCreator());
            // add parameter of the expense to the activity
            supportActionBar.setTitle(expense.getName());
            exp_amount.setText(value);
            exp_type.setText(type);
            exp_creator.setText(created_by);

            if (expense.getEmailPart() != null && expense.getSharePart() != null) {
                for (int i = 0; i < expense.nbrPart(); i++) {
                    addParticipant(expense.getEmailPart().get(i), expense.getSharePart().get(i));
                }
            } else {
                Log.d(TAG, "No participants to display for the expense: " + expense.toString());
            }
        } else {
            // user not logged in -> take him to the login activity
            Log.d(TAG, "User is not logged in");
            toLogin(ShowExpenseActivity.this);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        Log.d(TAG, "Launch onActivityResult");
        // if request from the modify activity
        if (requestCode == INT_MODIFY_EXPENSE) {
            // make sure the request was successful
            if (resultCode == RESULT_OK) {
                // Update the event
                expense = (Expense) data.getSerializableExtra("expense");

                // update the view
                supportActionBar.setTitle(expense.getName());
                exp_amount.setText(expense.getAmount() + "€");
                String type = (expense.getType() == null || expense.getType() == "") ? "" :
                        "Type: " + expense.getType();
                exp_type.setText(type);
                String created_by = "Paid by " + getEmailFromId(expense.getIdCreator());
                exp_creator.setText(created_by);

                for (int i=0; i < expense.nbrPart(); i++) {

                    Double value = Double.parseDouble(expense.getAmount()) *
                            Integer.parseInt(expense.getSharePart().get(i)) / expense.totShare();
                    // keep only 2 decimals
                    BigDecimal value_round = new BigDecimal(value);
                    value_round = value_round.setScale(2, RoundingMode.HALF_UP);
                    exp_list_share_text_view.get(i).setText(value_round + "€");
                }

                // TODO update the expense within the event (use a function...)


                Log.d(TAG, "Expense updated " + expense.toString());
            }
        }
    }

    // http://stackoverflow.com/questions/2679250/setresult-does-not-work-when-back-button-pressed
    @Override
    public void onBackPressed() {
        Intent intent = new Intent();
        intent.putExtra("updated_expense", expense);
        setResult(RESULT_OK, intent);
        super.onBackPressed();
    }


    public void goToModifyActivity()
    {
        Intent intent = new Intent(ShowExpenseActivity.this, ModifyExpenseActivity.class);
        intent.putExtra("expense", expense);
        startActivityForResult(intent, INT_MODIFY_EXPENSE);
        onStop();
    }


    /**
     * add to the view the participants and their share for this expense
     * @param part_email
     * @param part_share
     */
    public void addParticipant(String part_email, String part_share)
    {
        Resources r = getApplicationContext().getResources();
        int height = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
                50, r.getDisplayMetrics());
        final int padding = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
                10, r.getDisplayMetrics());

        LinearLayout lLayout = new LinearLayout(this);
        lLayout.setOrientation(LinearLayout.HORIZONTAL);
        lLayout.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView participant = new TextView(this);
        participant.setText(part_email);
        participant.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 20);
        participant.setTextColor(ContextCompat.getColor(getApplicationContext(),
                R.color.input_text));
        participant.setSingleLine();
        participant.setPadding(padding, padding, padding, padding);
        participant.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, height, 1f));

//        list_participants.add(participant);

        Double value = Double.parseDouble(expense.getAmount()) *
            Integer.parseInt(part_share) / expense.totShare();
        // keep only 2 decimals
        BigDecimal value_round = new BigDecimal(value);
        value_round = value_round.setScale(2, RoundingMode.HALF_UP);
        TextView share = new TextView(this);
        share.setText(value_round + "€");
        share.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 20);
        share.setTextColor(ContextCompat.getColor(getApplicationContext(),
                R.color.white));
        share.setTypeface(null, Typeface.BOLD);
        share.setGravity(Gravity.CENTER);
        share.setSingleLine();
        share.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, height, 3f));

        exp_list_share_text_view.add(share);

        lLayout.addView(participant);
        lLayout.addView(share);

        layout_participants.addView(lLayout);
    }


    /**
     * Get the email of a user bind to the expense
     * @param id
     * @return the email of the user
     */
    public String getEmailFromId(String id)
    {
        if (expense.nbrPart() == 0) return "";
        return expense.getEmailPart().get(expense.getIdPart().indexOf(id));
    }
}
