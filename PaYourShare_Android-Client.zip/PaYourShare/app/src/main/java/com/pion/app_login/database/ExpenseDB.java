package com.pion.app_login.database;


import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.pion.app_login.Expense;

import java.util.ArrayList;

/**
 * Created by pion on 14/12/15.
 */
public class ExpenseDB {
    private static final String TAG = ExpenseDB.class.getSimpleName();

    private SQLiteHandler handler;

    /**
     * Constructor of the class
     * @param handler
     */
    public ExpenseDB(SQLiteHandler handler) { this.handler = handler; }

    /**
     * Store an expense in the local database
     * @param expense
     */
    public void addExpense(Expense expense)
    {
        if (expense.notEmpty()) {
            // if the event to add already exists
            Expense exp_old = getExpense(expense.getId());
            if (exp_old.getId() != null) {
                Log.d(TAG, "Expense already exists in database: " + expense.toString());
                if (exp_old.getVersion() < expense.getVersion()) {
                    updateExpense(expense);
                } else {
                    Log.d(TAG, "Expense older than in the database: " + expense.toString());
                }
            } else {
                Log.d(TAG, "Create expense: " + expense.toString());

                SQLiteDatabase db = handler.getWritableDatabase();
                for (int i = 0; i < expense.nbrPart(); i++) {
                    ContentValues values = new ContentValues();
                    values.put(handler.KEY_EXPENSE_ID, expense.getId());
                    values.put(handler.KEY_EXPENSE_ID_EVENT, expense.getIdEvent());
                    values.put(handler.KEY_EXPENSE_NAME, expense.getName());
                    values.put(handler.KEY_EXPENSE_AMOUNT, expense.getAmount());
                    values.put(handler.KEY_EXPENSE_TYPE, expense.getType());
                    values.put(handler.KEY_EXPENSE_ID_CREATOR, expense.getIdCreator());
                    values.put(handler.KEY_EXPENSE_ID_PARTICIPANT, expense.getIdPart().get(i));
                    values.put(handler.KEY_EXPENSE_EMAIL_PARTICIPANT, expense.getEmailPart().get(i));
                    values.put(handler.KEY_EXPENSE_SHARE, expense.getSharePart().get(i));
                    values.put(handler.KEY_EXPENSE_VERSION, Integer.toString(expense.getVersion()));
                    values.put(handler.KEY_EXPENSE_CREATED_AT, expense.getCreatedAt());

                    // inserting row
                    long res = db.insert(handler.TABLE_EXPENSES, null, values);
                    Log.d(TAG, "New expense inserted into local database: " + res);
                }
                db.close();
            }
        } else {
            Log.d(TAG, "Error: could not create expense." +
                    "Expense is empty, no ids, no participants or no shares: " + expense.toString());
        }
    }

    /**
     * Get the details of an expense define by its id
     * @param id of the expense to fetch
     * @return
     */
    public Expense getExpense(String id) {
        SQLiteDatabase db = handler.getReadableDatabase();

        String selectQuery = "SELECT * FROM " + handler.TABLE_EXPENSES + " WHERE "
                + handler.KEY_EXPENSE_ID + " = " + "'" + id + "'";

        Cursor cursor = db.rawQuery(selectQuery, null);

        Expense expense = new Expense();
        ArrayList<String> list_ids = new ArrayList<String>();
        ArrayList<String> list_emails = new ArrayList<String>();
        ArrayList<String> list_share = new ArrayList<String>();

        // move to first row
        if (cursor.getCount() > 0) {
            if (cursor.moveToFirst()) {
                expense.setId(cursor.getString(
                        cursor.getColumnIndex(handler.KEY_EXPENSE_ID)));
                expense.setIdEvent(cursor.getString(
                        cursor.getColumnIndex(handler.KEY_EXPENSE_ID_EVENT)));
                expense.setName(cursor.getString(
                        cursor.getColumnIndex(handler.KEY_EXPENSE_NAME)));
                expense.setAmount(cursor.getString(
                        cursor.getColumnIndex(handler.KEY_EXPENSE_AMOUNT)));
                expense.setType(cursor.getString(
                        cursor.getColumnIndex(handler.KEY_EXPENSE_TYPE)));
                expense.setIdCreator(cursor.getString(
                        cursor.getColumnIndex(handler.KEY_EXPENSE_ID_CREATOR)));
                expense.setVersion(Integer.parseInt(cursor.getString(
                        cursor.getColumnIndex(handler.KEY_EXPENSE_VERSION))));
                expense.setCreatedAt(cursor.getString(
                        cursor.getColumnIndex(handler.KEY_EXPENSE_CREATED_AT)));

                // extract all the emails of the participants
                // and extract the share of each participant
                do {
                    list_ids.add(cursor.getString(
                            cursor.getColumnIndex(handler.KEY_EXPENSE_ID_PARTICIPANT)));
                    list_emails.add(cursor.getString(
                            cursor.getColumnIndex(handler.KEY_EXPENSE_EMAIL_PARTICIPANT)));
                    list_share.add(cursor.getString(
                            cursor.getColumnIndex(handler.KEY_EXPENSE_SHARE)));
                } while (cursor.moveToNext());

                expense.setIdPart(list_ids);
                expense.setEmailPart(list_emails);
                expense.setSharePart(list_share);
            }
            // log expense
            Log.d(TAG, "Expense fetched from local database: " + expense.toString());
        } else {
            Log.d(TAG, "Unable to fetch the expense from the local database, id_expense: " + id);
        }

        cursor.close();
        db.close();

        return expense;
    }

    /**
     * Return an array with all the id of the expenses relative to an event
     * @param id_event id of the event
     * @return
     */
    public ArrayList<String> getIdExpenses(String id_event)
    {
        Log.d(TAG, "Fetching expenses id from local database relative to id_event: " + id_event);

        SQLiteDatabase db = handler.getReadableDatabase();

        String selectQuery = "SELECT " + handler.KEY_EXPENSE_ID + " FROM " + handler.TABLE_EXPENSES
                + " WHERE " + handler.KEY_EXPENSE_ID_EVENT + " = " + "'" + id_event + "'";

        Cursor cursor = db.rawQuery(selectQuery, null);

        Log.d(TAG, selectQuery);

        ArrayList<String> id_expenses = new ArrayList<String>();
        if (cursor.getCount() > 0) {
            if (cursor.moveToFirst()) {
                do {
                    String id = cursor.getString(
                            cursor.getColumnIndex(handler.KEY_EXPENSE_ID));
                    if (!id_expenses.contains(id)) { // if id not already in the list
                        id_expenses.add(id); // add the id
                    }
                } while (cursor.moveToNext());
            }
        }

        cursor.close();
        db.close();

        if (id_expenses != null) {
            Log.d(TAG, id_expenses.size() + " fetched expenses id from SQLite: "
                    + id_expenses.toString());
        } else {
            Log.d(TAG, "No expense fetched from local database, id_event: " + id_event);
        }

        return id_expenses;
    }

    /**
     * Update the expense with the id in param
     * Delete the old expense and create a new one
     * @param expense
     */
    public void updateExpense(Expense expense)
    {
        Log.d(TAG, "Update expense: " + expense.toString());

        // delete the old expense
        deleteExpense(expense.getId());

        // create the new expense
        addExpense(expense);
    }

    /**
     * Delete the expense with the id in param from the local database
     * @param id
     */
    public void deleteExpense(String id)
    {
        Log.d(TAG, "Delete expense with id: " + id);

        SQLiteDatabase db = handler.getWritableDatabase();

        String deleteQuery = "DELETE FROM " + handler.TABLE_EXPENSES + " WHERE "
                + handler.KEY_EXPENSE_ID + " = " + "'" + id + "'" +";";

        db.execSQL(deleteQuery);
        db.close();
    }

    /**
     * Clear the local database by deleting all the expenses stored
     */
    public void deleteExpenses()
    {
        SQLiteDatabase db = handler.getWritableDatabase();
        // Delete all rows
        db.delete(handler.TABLE_EXPENSES, null, null);
        db.close();

        Log.d(TAG, "Deleted all expenses from SQLite");
    }

}
