package com.pion.app_login.activities;

import android.view.Menu;
import android.view.MenuItem;

import com.pion.app_login.R;

/**
 * Abstract class for ModifyEventActivity and ModifyExpenseActivity
 *
 * Created by pion on 24/01/16.
 */
abstract class ModifyActivity extends AppActivity {

    abstract void update();

    // TOOLBAR
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_save, menu);
        return true;
    }

    // action bar item click
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_save) {
            update();
            return true;
        } else if (id == R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
