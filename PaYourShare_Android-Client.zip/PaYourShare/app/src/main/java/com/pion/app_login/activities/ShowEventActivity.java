package com.pion.app_login.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.Toolbar;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.github.clans.fab.FloatingActionButton;

import com.pion.app_login.Event;
import com.pion.app_login.Expense;
import com.pion.app_login.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// TODO: 26/01/16 show a list of users on the activity

/**
 * Activity showing the details of an event and all its expenses
 *
 * <br><br>
 * Created by <i>pion</i> on 07/12/15.
 */
public class ShowEventActivity extends ShowActivity {
    public static String TAG = ShowEventActivity.class.getSimpleName();

    private Toolbar toolbar;
    private ActionBar supportActionBar;

    private TextView event_desc;
    private TextView event_creator;
    private Button showResults;
    private LinearLayout layout_expenses;
    private FloatingActionButton fab;

    private static Event event;

    private ArrayList<String> list_names;

    private List<String> exp_list_ids;
    private List<Button> exp_list_button;
    private List<Expense> exp_list_old;
    private List<Expense> exp_list_new;

    /**
     * Map between the id of an expense and the expense
     * contains all the expenses stored on the phone
     * expenses on there latest version known
     */
    private Map<String, Expense> local_expenses;
    /**
     * map the id and the version of an expense
     */
    private Map<String, Integer> map_id_to_version;
    /**
     * map the id and the button of an expense
     */
    private Map<String, Button> map_id_to_button;


    static final int INT_MODIFY_EVENT = 1; // the request code to modify an event
    static final int INT_CREATE_EXP = 2; // the request code to create an expense
    static final int INT_SHOW_EXP = 3; // the request code to show an expense

    @Override
    public void onCreate(Bundle savedInstancesState)
    {
        super.onCreate(savedInstancesState);
        setContentView(R.layout.show_event);
        Log.d(TAG, "ShowEventActivity launched");

        // toolbar
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        // add a return button to go to the previous activity
        supportActionBar = getSupportActionBar();
        supportActionBar.setDisplayHomeAsUpEnabled(true);

        // instantiate the views of the activity
        event_desc = (TextView) findViewById(R.id.show_event_desc);
        event_creator = (TextView) findViewById(R.id.show_event_creator);
        showResults = (Button) findViewById(R.id.show_results);
        layout_expenses = (LinearLayout) findViewById(R.id.show_expenses);
        fab = (FloatingActionButton) findViewById(R.id.fab_add_exp);

        // instantiate the other attributes
        exp_list_ids = new ArrayList<>();
        exp_list_button = new ArrayList<>();
        exp_list_old = new ArrayList<>();
        exp_list_new = new ArrayList<>();

        local_expenses = new HashMap<>();
        map_id_to_version = new HashMap<>();
        map_id_to_button = new HashMap<>();

        // check if user already logged in or not
        if (session.isLoggedIn()) {
            Log.d(TAG, "User is logged in");

            // get the event in parameter of the intent
            event = (Event) getIntent().getSerializableExtra("event");
            Log.d(TAG, "Event received from EventsActivity: " + event.toString());
            // get the list of expenses and store it
            exp_list_old = event.getListExpenses();

            // bind information about events to the view
            supportActionBar.setTitle(event.getName());
            String desc = (event.getDesc() == "") ? "" : "Desc: " + event.getDesc();
            event_desc.setText(desc);
            String created_by = "Created by " + getEmailFromId(event.getIdCreator());
            event_creator.setText(created_by);

            // load the expenses on the device
            loadLocalExpenses();

            showResults.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.d(TAG,"nbr exp: " + event.nbrExp());
                    Intent intent = new Intent(ShowEventActivity.this, ShowResultsActivity.class);
                    intent.putExtra("event", event);
                    //intent.putExtra("expenses", list_expenses);
                    startActivity(intent);
                    onStop();
                }
            });

            // Create expense floating action button
            fab.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Switching to create expense activity
                    Intent intent = new Intent(ShowEventActivity.this, CreateExpenseActivity.class);
                    intent.putExtra("event", event);
                    startActivityForResult(intent, INT_CREATE_EXP);
                    onStop(); // new activity launched => ShowEventActivity is put in background
                }
            });
        } else {
            // user not logged in -> take him to the login activity
            Log.d(TAG, "User is not logged in");
            toLogin(ShowEventActivity.this);
        }
    }

    @Override
    public void onRestart()
    {
        super.onRestart();
        Log.d(TAG, "onRestart");
        loadLocalExpenses();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        Log.d(TAG, "Launch onActivityResult");
        // if request from the modify activity
        switch (requestCode) {
            case INT_MODIFY_EVENT:
                // Result after event modification (as name, desc, users...)
                if (resultCode == RESULT_OK) { // make sure the request was successful
                    // Update the event
                    event = (Event) data.getSerializableExtra("event");

                    updateView();

                    Log.d(TAG, "Event updated " + event.toString());
                }
                break;
            case INT_CREATE_EXP:
                // Result after expense creation
                if (resultCode == RESULT_OK) { // make sure the request was successful
                    // Get the expense and add it to the event
                    Expense new_exp = (Expense) data.getSerializableExtra("new_expense");

                    // add the new exp to the event
                    event.addExp(new_exp);

                    // add the new expense to the list
                    local_expenses.put(new_exp.getId(), new_exp);

                    // add a button for this expense
                    addButton(new_exp);

                    Log.d(TAG, "New expense added to event: " + event.toString());
                }
                break;
            case INT_SHOW_EXP:
                // Result after expense creation
                if (resultCode == RESULT_OK) { // make sure the request was successful
                    // Get the expense and update it in the event
                    Expense received_expense = (Expense) data.getSerializableExtra("updated_expense");
                    String id_expense = received_expense.getId();
                    int received_version_exp = received_expense.getVersion();
                    int stored_version_exp = local_expenses.get(id_expense).getVersion();

                    // if newer version, then update the list of expenses and button
                    if (received_version_exp > stored_version_exp) {
                        // update the expense in the list of map
                        local_expenses.put(id_expense, received_expense);
                        // update the version in the map
                        map_id_to_version.put(id_expense, received_version_exp);
                        // update the button
                        Button button = map_id_to_button.get(id_expense);
                        button.setText(received_expense.getName());
                        // update the button in the map
                        map_id_to_button.put(id_expense, button);

                        // update the expense in the event
                        event.updateExp(received_expense);
                    }

                    Log.d(TAG, "update expense: " + received_expense.toString());
                }
                break;
            default: break;
        }
    }

    // http://stackoverflow.com/questions/2679250/setresult-does-not-work-when-back-button-pressed
    @Override
    public void onBackPressed() {
        Intent intent = new Intent();
        intent.putExtra("updated_event", event);
        setResult(RESULT_OK, intent);
        super.onBackPressed();
    }

    public void goToModifyActivity()
    {
        Intent intent = new Intent(ShowEventActivity.this, ModifyEventActivity.class);
        intent.putExtra("event", event);
        startActivityForResult(intent, INT_MODIFY_EVENT);
        onStop();
    }

    /**
     * Update the current view
     */
    public void updateView()
    {
        // change the title
        supportActionBar.setTitle(event.getName());
        // change description
        String desc = (event.getDesc() == "") ? "" : "Desc: " + event.getDesc();
        event_desc.setText(desc);

    }

    /**
     * Load the expenses of the event from the object <i>event</i>
     */
    public void loadLocalExpenses()
    {
        String id_event = event.getId();
        //Log.d(TAG, "Fetching the expenses from the local database of the id_event: " + id_event);

        for (Expense expense: event.getListExpenses()) {
            String id_expense = expense.getId();
            // add or update the events in the map
            local_expenses.put(id_expense, expense);

            // add a button for an expense
            // if not possess already a button
            if (!map_id_to_button.containsKey(id_expense)) {
                addButton(expense);
            } else {
                // already possess a button, then update it if newer version
                if (expense.getVersion() > map_id_to_version.get(id_expense)) {
                    Button button = map_id_to_button.get(id_expense);
                    button.setText(expense.getName());
                    // and update the button in the map
                    map_id_to_button.put(id_expense, button);
                    // and its version
                    map_id_to_version.put(id_expense, expense.getVersion());
                }
            }
        }

        // TODO call expense from database or from memory (an expense is binded to an event)
        /*ExpenseDB expDB = new ExpenseDB(handler);
        List<String> idExpenses = expDB.getIdExpenses(id_event);
        List<Expense> list_exp = new ArrayList<>();
        //List<Expense> list_exp = event.getListExpenses();
        Log.d(TAG, "nbr: " + event.nbrExp());
            /*for (int i=0; i < event.nbrExp(); i++) {
                Expense exp = list_exp.get(i);
                if (!exp_list_ids.contains(exp.getId())) {
                    // if not already shown, add it to the view
                    addButton(exp, i);
                    // and ad it to the lists
                    exp_list_ids.add(exp.getId());
                } else {
                    //if (exp_list_button.)
                    // if new version update button and its link
                }
            }*/


            /*for (int i = 0; i < idExpenses.size(); i++) {
                if (!exp_list_ids.contains(idExpenses.get(i))) { // keep just the new expenses
                    list_exp.add(expDB.getExpense(idExpenses.get(i)));
                }
                    // if an update occurred, replace the expense (to do else)
            }

            if (list_exp != null && list_exp.size() > 0) {
                for (int i = 0; i < list_exp.size(); i++) {
                    Expense expense = list_exp.get(i);
                    if (!exp_list_ids.contains(expense.getId())) { // keep just the new expenses
                        addButton(expense, i);
                        exp_list_ids.add(expense.getId());
                    }
                }
            event.setListExpenses(list_exp);
            }*/
    }

    /**
     * Add a button for an expense to the view and link it to the show expense activity
     * with the expense in extra
     * @param expense to add to the view
     */
    public void addButton(final Expense expense)
    {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int height = (int) (TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 80, dm));
        int top = (int) (TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 25, dm));
        //int txt_size = (int) (TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 30, dm));


        Button button = new Button(this);
        button.setHeight(height);
        button.setTop(top);
        button.setText(expense.getName());
        //button.setTextColor();
        layout_expenses.addView(button);

        // add the button to the list
        exp_list_button.add(button);

        // TODO update the expenses when event updated (participant removed)
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "open expenseViewActivity");

                goToShowExpense(expense.getId());
            }
        });

        // store the button in the map with the id_expense as key
        map_id_to_button.put(expense.getId(), button);
        // and store its version
        map_id_to_version.put(expense.getId(), expense.getVersion());
    }

    /**
     * This method allows to send the last version of an expense
     * When called, will start a ShowExpenseActivity and put the expense
     * with the id in parameter as extra to the intent
     * @param id_expense id of the expense to send to the next activity
     */
    public void goToShowExpense(String id_expense)
    {
        Intent intent = new Intent(ShowEventActivity.this, ShowExpenseActivity.class);
        intent.putExtra("expense", local_expenses.get(id_expense));
        startActivityForResult(intent, INT_SHOW_EXP);
        onPause();
    }

    /**
     * Get the email of a user bind to the expense
     * @param id of the user
     * @return the email of the user
     */
    public String getEmailFromId(String id)
    {
        if (event.getEmailUsers() == null || event.getEmailUsers().size() == 0) return "";
        return event.getEmailUsers().get(event.getIdUsers().indexOf(id));
    }

}
