package com.pion.app_login.database;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.pion.app_login.Event;
import com.pion.app_login.Expense;

import java.util.ArrayList;
import java.util.List;

/**
 * Interact with the table of events
 *
 * Created by pion on 02/12/15.
 */
public class EventsDB {
    private static final String TAG = EventsDB.class.getSimpleName();

    private SQLiteHandler handler;

    /**
     * Constructor of the class
     * @param handler
     */
    public EventsDB(SQLiteHandler handler)
    {
        this.handler = handler;
    }

    /**
     * Storing an event in database
     * @param event
     */
    public void addEvent(Event event)
    {
        if (event.notEmpty()) {
            // if the event to add already exists
            Event ev_old = getEvent(event.getId());
            if (ev_old.getId() != null) {
                Log.d(TAG, "Event already exists in database: " + event.toString());
                if (ev_old.getVersion() < event.getVersion()) {
                    updateEvent(event);
                } else {
                    Log.d(TAG, "Event older than in the database: " + event.toString());
                }
            } else {
                Log.d(TAG, "Create event: " + event.toString());

                SQLiteDatabase db = handler.getWritableDatabase();
                for (int i = 0; i < event.nbrUsers(); i++) {
                    ContentValues values = new ContentValues();
                    values.put(handler.KEY_EVENTS_ID, event.getId());
                    values.put(handler.KEY_EVENTS_NAME, event.getName());
                    values.put(handler.KEY_EVENTS_DESC, event.getDesc());
                    values.put(handler.KEY_EVENTS_ID_CREATOR, event.getIdCreator());
                    values.put(handler.KEY_EVENTS_ID_PARTICIPANT, event.getIdUsers().get(i));
                    values.put(handler.KEY_EVENTS_EMAIL_PARTICIPANT, event.getEmailUsers().get(i));
                    values.put(handler.KEY_EVENTS_ID_LIST_OF_USERS, event.getIdListOfUsers());
                    values.put(handler.KEY_EVENT_VERSION, Integer.toString(event.getVersion()));
                    values.put(handler.KEY_EVENTS_CREATED_AT, event.getCreatedAt());

                    // inserting row
                    long res = db.insert(handler.TABLE_EVENTS, null, values);
                    Log.d(TAG, "New event inserted into local database: " + res + " - " + event.toString());
                }
                db.close();
            }
        } else {
            Log.d(TAG, "Error: could not add the event." +
                    "Event is empty, no participants or no ids: " + event.toString());
        }

    }

    /**
     * Get the list of the events owned by a particular user from the database
     * @param id_user id of the user
     * @return a list of event
     */
    public List<Event> getEvents(String id_user)
    {
        List<Event> list_events = new ArrayList<>();
        List<String> list_id_events = getIdEvents(id_user);

        // get local events
        for (String id: list_id_events) {
            list_events.add(getEvent(id));
        }

        return list_events;
    }

    /**
     * Get a particular event from the database
     * @param id id of the event
     * @return an event
     */
    public Event getEvent(String id)
    {
        SQLiteDatabase db = handler.getReadableDatabase();

        String selectQuery = "SELECT * FROM " + handler.TABLE_EVENTS + " WHERE "
                + handler.KEY_EVENTS_ID + " = " + "'" + id + "'";

        Cursor cursor = db.rawQuery(selectQuery, null);

        Event event = new Event();
        List<String> list_ids = new ArrayList<String>();
        List<String> list_emails = new ArrayList<String>();

        // move to first row
        if (cursor.getCount() > 0) {
            if (cursor.moveToFirst()) {
                event.setId(cursor.getString(
                        cursor.getColumnIndex(handler.KEY_EVENTS_ID)));
                event.setName(cursor.getString(
                        cursor.getColumnIndex(handler.KEY_EVENTS_NAME)));
                event.setDesc(cursor.getString(
                        cursor.getColumnIndex(handler.KEY_EVENTS_DESC)));
                event.setIdCreator(cursor.getString(
                        cursor.getColumnIndex(handler.KEY_EVENTS_ID_CREATOR)));
                event.setIdListOfUsers(cursor.getString(
                        cursor.getColumnIndex(handler.KEY_EVENTS_ID_LIST_OF_USERS)));
                event.setVersion(Integer.parseInt(cursor.getString(
                        cursor.getColumnIndex(handler.KEY_EVENT_VERSION))));
                event.setCreatedAt(cursor.getString(
                        cursor.getColumnIndex(handler.KEY_EVENTS_CREATED_AT)));

                // extract all the id of the participants of the event
                // and extract all the email of the participants of the event
                do {
                    list_ids.add(cursor.getString(cursor.getColumnIndex(handler.KEY_EVENTS_ID_PARTICIPANT)));
                    list_emails.add(cursor.getString(cursor.getColumnIndex(handler.KEY_EVENTS_EMAIL_PARTICIPANT)));
                } while (cursor.moveToNext());

                event.setIdUsers(list_ids);
                event.setEmailUsers(list_emails);
            }

            // fetch the expenses and add them to the event
            ExpenseDB expenseDB = new ExpenseDB(handler);
            List<String> list_id_exp = expenseDB.getIdExpenses(id);
            List<Expense> list_exp = new ArrayList<>();
            for (String id_exp: list_id_exp) {
                list_exp.add(expenseDB.getExpense(id_exp));
            }
            event.setListExpenses(list_exp);

            // log event
            Log.d(TAG, "Event fetched from local database: " + event.toString());
        } else {
            Log.d(TAG, "Unable to fetch the event from the local database, id_event: " + id);
        }

        cursor.close();
        db.close();

        return  event;
    }

    /**
     * Get the ids of the events owned by a particular user from the database
     * @param id_user id of the user
     * @return an list of ids (list of string)
     */
    public List<String> getIdEvents(String id_user)
    {
        Log.d(TAG, "Fetching events id from local database relative to id_user: " + id_user);

        SQLiteDatabase db = handler.getReadableDatabase();

        String selectQuery = "SELECT " + handler.KEY_EVENTS_ID + " FROM " + handler.TABLE_EVENTS
                + " WHERE " + handler.KEY_EVENTS_ID_PARTICIPANT + " = " + "'" + id_user + "'";

        Cursor cursor = db.rawQuery(selectQuery, null);

        Log.d(TAG, selectQuery);

        List<String> id_events = new ArrayList<String>();
        if (cursor.getCount() > 0) {
            if (cursor.moveToFirst()) {
                do {
                    String id = cursor.getString(
                            cursor.getColumnIndex(handler.KEY_EVENTS_ID));
                    if (!id_events.contains(id)) { // if the id not already in the list
                        id_events.add(id); // add the id
                    }
                } while (cursor.moveToNext());
            }
        }

        cursor.close();
        db.close();

        if (id_events != null) {
            Log.d(TAG, id_events.size() + " fetched events id from SQLite: "
                    + id_events.toString());
        } else {
            Log.d(TAG, "No event fetched from local database, id_user: " + id_user);
        }

        return id_events;
    }

    /**
     * Get the email of each participant of an event
     * @param id_event id of the event
     * @return a list email (list of string)
     */
    public List<String> getEmailUsers(String id_event)
    {
        Log.d(TAG, "Fetching the emails of the participants of the event " + id_event);

        SQLiteDatabase db = handler.getReadableDatabase();

        String selectQuery = "SELECT " + handler.KEY_EVENTS_EMAIL_PARTICIPANT + " FROM "
                + handler.TABLE_EVENTS + " WHERE " + handler.KEY_EVENTS_ID + " = '"
                + id_event + "'";

        Cursor cursor = db.rawQuery(selectQuery, null);

        Log.d(TAG, selectQuery);

        List<String> list_emails = new ArrayList<String>();
        if (cursor.getCount() > 0) {
            if (cursor.moveToFirst()) {
                do {
                    list_emails.add(cursor.getString(
                            cursor.getColumnIndex(handler.KEY_EVENTS_EMAIL_PARTICIPANT)));
                } while (cursor.moveToNext());
            }
        }

        cursor.close();
        db.close();

        Log.d(TAG, "List of the emails: " + list_emails.toString());
        return list_emails;
    }

    /**
     * Update the event with the id in param
     * Delete the old event and create a new one
     * @param event event to update
     */
    public void updateEvent(Event event)
    {
        Log.d(TAG, "Update the event: " + event.toString());

        // delete the old event
        deleteEvent(event.getId());

        // create the new event
        addEvent(event);
    }


    /**
     * Delete the event with the id in param from the local database
     * @param id id of the event to delete
     */
    public void deleteEvent(String id)
    {
        Log.d(TAG, "Delete the event with id: " + id);

        SQLiteDatabase db = handler.getWritableDatabase();

        String deleteQuery = "DELETE FROM " + handler.TABLE_EVENTS + " WHERE "
                + handler.KEY_EVENTS_ID + " = " + "'" + id + "'" + ";";

        db.execSQL(deleteQuery);
        db.close();
    }

    /**
     * Clear the local database (delete all the events)
     */
    public void deleteEvents() {
        SQLiteDatabase db = handler.getWritableDatabase();
        // Delete all rows
        db.delete(handler.TABLE_EVENTS, null, null);
        db.close();

        Log.d(TAG, "Deleted all events from SQLite");
    }

}
