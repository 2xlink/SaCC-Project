package com.pion.app_login.database;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.pion.app_login.User;
import com.pion.app_login.res.Resource;

/**
 * Interact with the table of user in SQLite
 * the database only stores one user (the current user of the app)
 *
 * Created by pion on 02/12/15.
 */
public class UserDB {
    private static String TAG = UserDB.class.getSimpleName();

    private SQLiteHandler handler;

    /**
     * Constructor of the class
     * @param handler
     */
    public UserDB(SQLiteHandler handler)
    {
        this.handler = handler;
    }

    /**
     * Storing a new user in database
     * @param user
     */
    public void addUser(User user)
    {
        SQLiteDatabase db = handler.getWritableDatabase();
        ContentValues values = new ContentValues();
            values.put(handler.KEY_USER_ID, user.getId()); // uid
            values.put(handler.KEY_USER_TOKEN, user.getToken()); // token
            values.put(handler.KEY_USER_NAME, user.getName()); //name
            values.put(handler.KEY_USER_EMAIL, user.getEmail()); // email
            values.put(handler.KEY_USER_CREATED_AT, handler.getDateTime()); // created_at

        // inserting row
        long id = db.insert(handler.TABLE_USER, null, values);
        db.close(); // closing database connection

        Log.d(TAG, "New user inserted into SQLite: " + id);
    }

    /**
     * Getting user details from database
     * @return user
     */
    public User getUser()
    {
        SQLiteDatabase db = handler.getReadableDatabase();

        String selectQuery = "SELECT * FROM " + handler.TABLE_USER + ";";

        Log.d(TAG, selectQuery);

        Cursor cursor = db.rawQuery(selectQuery, null);

        User user = new User();

        // Move to first row
        if (cursor != null  && cursor.getCount()>0) {
            cursor.moveToFirst();

            user.setId(cursor.getString(cursor.getColumnIndex(handler.KEY_USER_ID)));
            user.setToken(cursor.getString(cursor.getColumnIndex(handler.KEY_USER_TOKEN)));
            user.setName(cursor.getString(cursor.getColumnIndex(handler.KEY_USER_NAME)));
            user.setEmail(cursor.getString(cursor.getColumnIndex(handler.KEY_USER_EMAIL)));
            user.setCreatedAt(cursor.getString(cursor.getColumnIndex(handler.KEY_USER_CREATED_AT)));
        } else {
            Log.d(TAG, "No user found in the database");
        }

        cursor.close();
        db.close();

        // return user
        Log.d(TAG, "User fetched from local database: " + user.toString());

        return user;

    }

    // TODO update user
    /**
     * Update user
     */
    public void updateUser()
    {
        SQLiteDatabase db = handler.getWritableDatabase();
        db.close();
    }

    /**
     * Clear the database
     */
    public void deleteUser() {
        SQLiteDatabase db = handler.getWritableDatabase();
        // Delete all rows
        db.delete(handler.TABLE_USER, null, null);
        db.close();

        Log.d(TAG, "User deleted from local database");
    }

}
