package com.pion.app_login;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by pion on 14/12/15.
 */
public class Expense implements Serializable {
    private String id;
    private String id_event;
    private String name;
    private String amount;
    private String type;
    private String id_creator;
    private List<String> id_part;
    private List<String> email_part;
    private List<String> share_part;
    private int version;
    private String created_at;

    public Expense()
    {
        this.id_part = new ArrayList<>();
        this.email_part = new ArrayList<>();
        this.share_part = new ArrayList<>();
    }

    public Expense(String id, String id_event, String name, String amount, String type,
                   String id_creator, List<String> id_part,
                   List<String> email_part, List<String> share_part,
                   String created_at)
    {
        this.id = id;
        this.id_event = id_event;
        this.name = name;
        this.amount = amount;
        this.type = type;
        this.id_creator = id_creator;
        this.id_part = id_part;
        this.email_part = email_part;
        this.share_part = share_part;
        this.created_at = created_at;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getIdEvent() { return id_event; }
    public void setIdEvent(String id_event) { this.id_event = id_event; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getAmount() { return amount; }
    public void setAmount(String amount) { this.amount = amount; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public String getIdCreator() { return id_creator; }
    public void setIdCreator(String id_creator) { this.id_creator = id_creator; }

    public List<String> getIdPart() { return id_part; }
    public void setIdPart(List<String> id_part) { this.id_part = id_part; }

    public List<String> getEmailPart() { return email_part; }
    public void setEmailPart(List<String> email_part) { this.email_part = email_part; }

    public List<String> getSharePart() { return share_part; }
    public void setSharePart(List<String> share_part) { this.share_part = share_part; }

    public int getVersion() { return version; }
    public void setVersion(int version) { this.version = version; }

    public String getCreatedAt() { return created_at; }
    public void setCreatedAt(String created_at) { this.created_at = created_at; }

    public String toString()
    {
        String s = "id: " + this.id
                + " - id_event: " + this.id_event
                + " - name: " + this.name
                + " - amount: " + this.amount
                + " - type: " + this.type
                + " - id_creator: " + this.id_creator
                + " - id_part: " + this.id_part.toString()
                + " - email_part: " + this.email_part.toString()
                + " - share_part: " + this.share_part.toString()
                + " - version: " + Integer.toString(this.version)
                + " - created_at: " + this.created_at;
        return s;
    }

    /**
     * @return true if the lists of attributs are not null and not empty
     */
    public boolean notEmpty()
    {
        if (id_part != null && email_part != null && share_part != null) {
            if (id_part.size() > 0 && email_part.size() > 0 && share_part.size() > 0) {
                return true;
            } else return false;
        }
        else return false;
    }

    /**
     * @return the number of participants of the expense
     */
    public int nbrPart()
    {
        if (id_part.size() == email_part.size() && id_part.size() == share_part.size()) {
            return id_part.size();
        }
        else return 0;
    }

    /**
     * @return the total amount of shares of the expense
     */
    public int totShare()
    {
        int tot_shares = 0;
        for (String share : share_part) {
            tot_shares += Integer.parseInt(share);
        }
        return tot_shares;
    }
}
