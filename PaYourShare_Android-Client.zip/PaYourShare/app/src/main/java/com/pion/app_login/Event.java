package com.pion.app_login;

import android.util.Log;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Event object (attributes and key values are the same)
 *
 * Created by pion on 02/12/15.
 */
public class Event implements Serializable {
    private static String TAG = Event.class.getSimpleName();

    private String id;
    private String name;
    private String desc;
    private String id_creator;
    private List<String> id_users;
    private List<String> email_users;
    private String id_listOfUsers;
    private int version;
    private String created_at;
    private String updated_at;

    // TODO: 27/01/16 use a map id_expense <-> expense
    private List<Expense> listExpenses;

    // private String id_lastUpdate; // id of the user who did the last update

    // Constructors
    public Event()
    {
        listExpenses = new ArrayList<>();
    }

    public Event(String name, String desc, String id_creator,
                 String id_listOfUsers, String created_at)
    {
        this.name = name;
        this.desc = desc;
        this.id_creator = id_creator;
        this.id_listOfUsers = id_listOfUsers;
        this.created_at = created_at;

        listExpenses = new ArrayList<>();
    }

    public Event(String id, String name, String desc, String id_creator,
                 String id_listOfUsers, String created_at)
    {
        this.id = id;
        this.name = name;
        this.desc = desc;
        this.id_creator = id_creator;
        this.id_listOfUsers = id_listOfUsers;
        this.created_at = created_at;

        listExpenses = new ArrayList<>();
    }

    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDesc() { return desc; }
    public void setDesc(String desc) { this.desc = desc; }

    public String getIdCreator() { return id_creator; }
    public void setIdCreator(String id_creator) { this.id_creator = id_creator; }

    public List<String> getIdUsers() { return id_users; }
    public void setIdUsers (List<String> listIds) { this.id_users = listIds; }

    public List<String> getEmailUsers() { return email_users; }
    public void setEmailUsers(List<String> listEmails) { this.email_users = listEmails; }

    public String getIdListOfUsers() { return id_listOfUsers; }
    public void setIdListOfUsers(String id_listOfUsers) { this.id_listOfUsers = id_listOfUsers; }

    public int getVersion() { return version; }
    public void setVersion(int version) { this.version = version; }

    public String getCreatedAt() { return created_at; }
    public void setCreatedAt(String created_at) { this.created_at = created_at; }

    public String getUpdatedAt() { return updated_at; }
    public void setUpdatedAt(String updated_at) { this.updated_at = updated_at; }

    public List<Expense> getListExpenses() { return listExpenses; }
    public void setListExpenses(List<Expense> l_exp) { this.listExpenses = l_exp; }

    public String toString() {
        String s = "id: " + this.id
                + " - name: " + this.name
                + " - desc: " + this.desc
                + " - id_creator: " + this.id_creator
                + " - id_users: " + this.id_users.toString()
                + " - email_users: " + this.email_users.toString()
                + " - id_listUser: " + this.id_listOfUsers
                + " - list_exp: " + this.listExpenses.toString()
                + " - version: " + Integer.toString(this.version)
                + " - created_at: " + this.created_at;
        return s;
    }

    /**
     * @return true if the lists of attributes are not null and not empty
     */
    public boolean notEmpty()
    {
        if (id_users != null && email_users != null) {
            if (id_users.size() > 0 && email_users.size() > 0) {
                return true;
            } else return false;
        }
        else return false;
    }

    /**
     * @return the number of users of the event
     */
    public int nbrUsers()
    {
        return (id_users.size() == email_users.size()) ? id_users.size() : 0;
    }

    /**
     * @return the number of expenses related to the event
     */
    public int nbrExp()
    {
        Log.d(TAG, "size: " + listExpenses.size());
        return (listExpenses == null) ? 0 : listExpenses.size();
    }

    /**
     * remove a user from an event
     * @param id of the user
     * @param email of the user
     */
    public void removePart(String id, String email)
    {
        // TODO check if removePart is interfering with the list of users, ids and share of the expenses
        List<String> cop_list_id_part = id_users;
        List<String> cop_list_email_part = email_users;

        if (cop_list_id_part.remove(id) && cop_list_email_part.remove(email)) {
            Log.d(TAG, "Remove the participant from the event");
            setIdUsers(cop_list_id_part);
            setEmailUsers(cop_list_email_part);

            // remove the participant from the expenses
            List<Expense> cop_list_exp = listExpenses;
            for (Expense exp: cop_list_exp) {
                int pos = exp.getIdPart().indexOf(id);
                // check if positions are the same in both lists
                if (pos == exp.getEmailPart().indexOf(email)) {
                    // check if removed without error
                    if (exp.getIdPart().remove(id) && exp.getEmailPart().remove(email)) {
                        // remove the share too
                        exp.getSharePart().remove(pos);
                    } else {
                        Log.d(TAG, "Could not remove the id or the email of the participant from " +
                                "the events");
                    }
                } else {
                    Log.d(TAG, "Position index of id and email are not the same " +
                            "in id_part and email_part lists");
                }
            }
            Log.d(TAG, "Remove the participant from the expenses");
            setListExpenses(cop_list_exp);
        } else {
            Log.d(TAG, "Error: could not remove the participant from the event");
        }

    }

    /**
     * Add an expense to the list of expenses of the event
     * @param exp to add
     */
    public void addExp(Expense exp) {
        listExpenses.add(exp);
        this.version += 1; // incrementation of the event version
    }

    /**
     * Update a specific expense in the list of the expenses of the event
     * @param new_expense updated expense
     */
    public void updateExp(Expense new_expense) {
        // search for the index of the expense in the list of expenses
        int index = -1;
        for (Expense exp: listExpenses) {
            if(exp.getId().equals(new_expense.getId())) {
                index = listExpenses.indexOf(exp);
                break;
            }
        }
        if (index != -1) {
            listExpenses.set(index, new_expense);
            this.version += 1; // incrementation of the event version

            Log.d(TAG, "Expense update in the event: " + this.toString());
        }
        else {
            Log.d(TAG, "Impossible to update the expense, index not found: " + new_expense.toString());
        }

    }

}
