package com.pion.app_login.activities;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.util.TypedValue;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.pion.app_login.Event;
import com.pion.app_login.Expense;
import com.pion.app_login.R;
import com.pion.app_login.res.Resource;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Show an activity with how much someone owes to someone else
 *
 * TODO show the best solution (remove intermediaries)
 * Created by pion on 24/12/15.
 */
public class ShowResultsActivity extends AppActivity {
    private static final String TAG = ShowResultsActivity.class.getSimpleName();

    private Toolbar toolbar;

    private Event event;
    private List<Expense> list_expenses;

    @Override
    public void onCreate(Bundle savedInstancesState) {
        super.onCreate(savedInstancesState);
        setContentView(R.layout.show_results);
        Log.d(TAG, "ShowResultsActivity launched");

        // toolbar
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        // add a return button to go to the previous activity
        final ActionBar supportActionBar = getSupportActionBar();
        supportActionBar.setDisplayHomeAsUpEnabled(true);


        // check if user already logged in or not
        if (session.isLoggedIn()) {
            Log.d(TAG, "User is logged in");

            event = (Event) getIntent().getSerializableExtra("event");
            event.nbrExp();
            Log.d(TAG, "event: " + event.toString());


            //list_expenses = (List<Expense>) getIntent().getSerializableExtra("expenses");
            list_expenses = event.getListExpenses();
            // show the total
            TextView show_tot = (TextView) findViewById(R.id.show_results_tot);
            double tot = 0.0;
            if (list_expenses != null && list_expenses.size() > 0) {
                for (Expense exp: list_expenses) {
                    tot += Double.parseDouble(exp.getAmount());
                }
                show_tot.setText("Total sum: " + tot + "€");
                algo(event);
            }
        } else {
            // user not logged in -> take him to the login activity
            Log.d(TAG, "User is not logged in");
            Intent intent = new Intent(ShowResultsActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        }
    }

    // TOOLBAR
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_more, menu);
        return true;
    }

    // action bar item click
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_more) {
            return true;
        } else if (id == R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * Display the result on the view
     * @param map_list
     * @param list_users
     */
    public void addResult(List<Map<String, Double>> map_list, List<String> list_users)
    {
        // TODO: 26/01/16 add a drop shadow like under the toolbar (see xml file)
        Resources r = getApplicationContext().getResources();
        Context context = getApplicationContext();
        int margin_5 = Resource.dpToPx(context, 5);
        int margin_10 = Resource.dpToPx(context, 10);
        int margin_20 = Resource.dpToPx(context, 20);
        int padding = Resource.dpToPx(context, 10);
        int txt_size = 20;

        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        );


        // layout params for the parent layout
        LinearLayout.LayoutParams lay_param_parent = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lay_param_parent.setMargins(0, margin_10, 0, 0);

        // layout params for the inner layout
        LinearLayout.LayoutParams lay_param_inner = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lay_param_inner.setMargins(margin_20, margin_5, 0, 0);

        for (int i=0; i < map_list.size(); i++) {
            Map<String, Double> map = map_list.get(i);
            if (map.size() > 0) {
                String payer = list_users.get(i);

                LinearLayout lay_parent = new LinearLayout(this);
                lay_parent.setLayoutParams(lay_param_parent);
                lay_parent.setOrientation(LinearLayout.VERTICAL);
                lay_parent.setBackgroundColor(ContextCompat.getColor(getApplicationContext(),
                        R.color.colorSecondary));
                lay_parent.setPadding(padding, padding, padding, padding);

                String payer_txt = payer + " ows to";
                TextView payer_tv = new TextView(this);
                payer_tv.setText(payer_txt);
                payer_tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, txt_size);
                payer_tv.setTextColor(ContextCompat.getColor(getApplicationContext(),
                        R.color.input_text));
                payer_tv.setLayoutParams(layoutParams);

                lay_parent.addView(payer_tv);


                // for each value of the map
                for (Map.Entry<String, Double> entry: map.entrySet()) {
                    String receiver = entry.getKey();
                    Double value = entry.getValue();

                    // keep only 2 decimals to value
                    BigDecimal value_round = new BigDecimal(value);
                    value_round = value_round.setScale(2, RoundingMode.HALF_UP);

                    LinearLayout lay_inner = new LinearLayout(this);
                    lay_inner.setLayoutParams(lay_param_inner);
                    lay_inner.setOrientation(LinearLayout.HORIZONTAL);

                    TextView to = new TextView(this);
                    to.setText("->");
                    to.setTextSize(TypedValue.COMPLEX_UNIT_DIP, txt_size);
                    to.setTextColor(ContextCompat.getColor(getApplicationContext(),
                            R.color.input_text));
                    to.setLayoutParams(new LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            2f));

                    TextView receiver_tv = new TextView(this);
                    receiver_tv.setText(receiver);
                    receiver_tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, txt_size);
                    receiver_tv.setTextColor(ContextCompat.getColor(getApplicationContext(),
                            R.color.input_text));
                    receiver_tv.setLayoutParams(new LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            1f));

                    TextView value_tv = new TextView(this);
                    value_tv.setText(value_round + "€");
                    value_tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, txt_size);
                    value_tv.setTextColor(ContextCompat.getColor(getApplicationContext(),
                            R.color.input_text));
                    value_tv.setLayoutParams(new LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            2f));

                    lay_inner.addView(to);
                    lay_inner.addView(receiver_tv);
                    lay_inner.addView(value_tv);

                    lay_parent.addView(lay_inner);
                }

                LinearLayout show_results = (LinearLayout) findViewById(R.id.layout_show_results);
                show_results.addView(lay_parent);
            }
        }
    }

    /**
     * Several parts in this algorithm
     * 1. First create a list of map where each map maps a user and a value
     * for instance user1 paid for user2 and himself 10€, the list of map looks like
     * [(user1 => 5), (user2 => 5)]
     *
     * 2. The second idea is to erase the redundancy
     * for instance if user1 ows 5€ to user2 and user2 ows 10€ to user1
     * the program should say that user2 ows 5€ to user1
     * that is the idea behind the <i>mapList_small</i>
     * During this study, we erase also the entry to 0 (user1 <-> user1)
     *
     * 3. Then it is time to know in which direction the money has to go
     * in other words, who ows money ? To do so, look the value, if positive
     * propagation un the right way, else inverse it and the value too.
     *
     * 4. Reorganize the list in order to show the persons a user must pay
     *
     * 5. Call a function to add this information to the view
     *
     * Note : whe worked with 'negative' values, it means that we studied the problem
     * from the point of view of the payer (the money is then seen as negative value for
     * the other participants because it will be a loss for them)
     *
     * TODO: determine the smaller number of interaction between people
     *
     * @param event the event used for the calculation
     */
    public void algo(Event event)
    {
        List<String> list_users = event.getEmailUsers();
        List<String> list_ids = event.getIdUsers();
        int nbr_user = event.nbrUsers();

        Log.d(TAG, "list users: " + list_users);
        Log.d(TAG, "list ids: " + list_ids);

        List<Map<String, Double>> mapList = new ArrayList<>();
        for (int i=0; i < nbr_user; i++) {
            mapList.add(i, new HashMap<String, Double>());
        }
        List<String> list_paid_by = new ArrayList<>();

        Log.d(TAG, "list expense: " + event.getListExpenses());

        // put together the expense made by the same person
        for (int e=0; e < event.nbrExp(); e++) {
            // expense
            Expense exp = event.getListExpenses().get(e);
            // paid by
            String paid_by = list_users.get(
                    list_ids.indexOf(exp.getIdCreator()));
            // amount of the expense
            double amount = Double.parseDouble(exp.getAmount());
            // total of shares
            int tot_shares = exp.totShare();

            Log.d(TAG, "exp: " + exp.toString());
            Log.d(TAG, "paid by: " + paid_by
                    + " - amount: " + amount
                    + " - tot_share: " + tot_shares);

            Map<String, Double> map_exp = new HashMap<>();
            for (int i=0; i < nbr_user; i++) {
                Double value;
                if (list_users.get(i).equals(paid_by)) {
                    value = 0.0;
                } else {
                    // TODO: 27/01/16  get an error nullpointer exception with alexis tst
                    value = - amount * Integer.parseInt(exp.getSharePart().get(i)) / tot_shares;
                }
                Log.d(TAG, "value: " + value);

                map_exp.put(list_users.get(i), value);
            }

            // if user paid_by already exists
            // then modify the list (add the new value to the field)
            if (list_paid_by.contains(paid_by)) {
                // get the old hashmap
                Map<String, Double> map_exp_old = mapList.get(list_paid_by.indexOf(paid_by));
                Map<String, Double> map_exp_new = new HashMap<>();

                // fill the new map with the sum of the 2 other
                for (String user_email: list_users) {
                    map_exp_new.put(user_email,
                            map_exp_old.get(user_email) + map_exp.get(user_email));
                }

                // replace in the list
                mapList.set(list_users.indexOf(paid_by), map_exp_new);

            } else {
                // add to the list
                //mapList.add(map_exp);
                // replace in the list
                mapList.set(list_users.indexOf(paid_by), map_exp);
                list_paid_by.add(paid_by);
            }
        }

        Log.d(TAG, "list_users: " + list_users.toString());
        Log.d(TAG, "list_paid_by: " + list_paid_by.toString());
        Log.d(TAG, "size list_paid_by: " + list_paid_by.size());
        Log.d(TAG, "mapList: " + mapList.toString());



        // when u1 and u2 own money to each other, determine who ows who
        List<Map<String, Double>> mapList_small = new ArrayList<>();
        // use a copy of the list of user in which we remove the root_user in each loop
        List<String> list_rest_users = new ArrayList<>(list_users);
        // go through the mapList
        for (int i=0; i < list_paid_by.size(); i++) {
            String root_user = list_paid_by.get(i);
            // remove the user from the list
            list_rest_users.remove(root_user);
            Log.d(TAG, "list_rest_users " + list_rest_users.toString());

            Map<String, Double> map_exp_small = new HashMap<>();
            // loop on the list without the previous root user
            // -> the bind between 2 users appears only one time
            for (int j = 0; j < list_rest_users.size(); j++) {
                String map_user = list_rest_users.get(j);
                Double value = mapList.get(list_users.indexOf(root_user)).get(map_user);
                // if another link between two users exists in an other map of the list
                // then subtracts its value
                if (mapList.get(list_users.indexOf(map_user)).containsKey(root_user)) {
                    value -= mapList.get(list_users.indexOf(map_user)).get(root_user);
                }

                if (root_user != map_user) {
                    map_exp_small.put(map_user, value);
                }
            }

            // add the map to the list
            mapList_small.add(map_exp_small);
        }

        Log.d(TAG, "mapList_small: " + mapList_small.toString());


        // reorganize the list of maps
        // determine who ows who
        List<Map<String, Double>> mapList_ows = new ArrayList<>();
        for (int i=0; i < nbr_user; i++) {
            mapList_ows.add(i, new HashMap<String, Double>());
        }
        for (int i=0; i < mapList_small.size(); i++) {
            String payer = list_paid_by.get(i);
            Map<String, Double> map = mapList_small.get(i);
            Log.d(TAG, "map: " + map.toString());

            // for each value of the map
            // to burrow = emprunter
            for (Map.Entry<String, Double> entry: map.entrySet()) {
                String receiver = entry.getKey();
                Double value = entry.getValue();

                // if value < 0
                // then payer and receiver have to be changed
                String payer_new = (value < 0) ? receiver : payer;
                String receiver_new = (value < 0) ? payer : receiver;
                Double value_new = (value < 0) ? -value : value;

                Log.d(TAG, "payer: " + payer_new
                        + " - receiver: " + receiver_new
                        + " - value: " + value_new);

                if (value != 0 ) {
                    int index = list_users.indexOf(payer_new);
                    Map<String, Double> map_ows = mapList_ows.get(index);
                    map_ows.put(receiver_new, value_new);
                    mapList_ows.set(index, map_ows);
                }
            }
        }

        Log.d(TAG, "mapList_ows: " + mapList_ows.toString());

        // finally call the method to display the infos to the view
        addResult(mapList_ows, list_users);

    }
}
