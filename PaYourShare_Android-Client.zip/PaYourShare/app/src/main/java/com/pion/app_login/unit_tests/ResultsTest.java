package com.pion.app_login.unit_tests;

import android.test.InstrumentationTestCase;

import com.pion.app_login.Event;
import com.pion.app_login.Expense;
import com.pion.app_login.activities.ShowResultsActivity;

import java.util.ArrayList;
import java.util.List;

/**
 * Tests
 * /!\ All the tests methods must begin with the "test" prefix /!\
 * http://rexstjohn.com/unit-testing-with-android-studio/
 *
 * Created by pion on 27/12/15.
 */
public class ResultsTest extends InstrumentationTestCase {
    /*public void test() throws Exception {
        final int expected = 3;
        final int reality = 5;
        assertEquals(expected, reality);
    }*/

    public void testAlgo() throws Exception {
        List<String> list_id_users = new ArrayList<String>();
        list_id_users.add("20");
        list_id_users.add("21");
        list_id_users.add("22");
        List<String> list_email_users = new ArrayList<String>();
        list_email_users.add("tst1@tst.org");
        list_email_users.add("tst2@tst.org");
        list_email_users.add("tst3@tst.org");
        List<String> list_share_users0 = new ArrayList<String>();
        list_share_users0.add("1");
        list_share_users0.add("1");
        list_share_users0.add("1");
        List<String> list_share_users1 = new ArrayList<String>();
        list_share_users1.add("1");
        list_share_users1.add("0");
        list_share_users1.add("4");
        List<String> list_share_users2 = new ArrayList<String>();
        list_share_users2.add("1");
        list_share_users2.add("1");
        list_share_users2.add("0");
        List<String> list_share_users3 = new ArrayList<String>();
        list_share_users3.add("0");
        list_share_users3.add("0");
        list_share_users3.add("1");

        Event event = new Event();
        event.setId("0");
        event.setName("tst");
        event.setDesc("");
        event.setIdCreator("1");
        event.setIdUsers(list_id_users);
        event.setEmailUsers(list_email_users);
        event.setIdListOfUsers("");
        event.setCreatedAt("");

        Expense expense0 = new Expense("10", "0", "exp", "15", "", "20",
                list_id_users, list_email_users, list_share_users0, "");
        Expense expense1 = new Expense("11", "0", "exp1", "10", "", "21",
                list_id_users, list_email_users, list_share_users1, "");
        Expense expense2 = new Expense("11", "0", "exp1", "10", "", "21",
                list_id_users, list_email_users, list_share_users2, "");
        Expense expense3 = new Expense("11", "0", "exp1", "7", "", "22",
                list_id_users, list_email_users, list_share_users3, "");

        List<Expense> list_expense = new ArrayList<Expense>();
        list_expense.add(expense0);
        list_expense.add(expense1);
        list_expense.add(expense2);
        list_expense.add(expense3);

//        double [][] result = { {0,5,0}, {5,0,0}, {5,8,0} };
        double [][] result = { {0,5,5}, {7,0,8}, {0,0,0} };


        int n = event.nbrUsers();
        double [][] array = new double[n][n];

        for (Expense expense: list_expense) {
            // determine position in the array of the person who paid the expense
            int pos_creator = expense.getIdPart().indexOf(expense.getIdCreator());

            // value of the expense
            double value = Double.parseDouble(expense.getAmount());

            // total of shares
            int tot_shares = 0;
            for (String share : expense.getSharePart()) {
                tot_shares += Integer.parseInt(share);
            }

            // fill the array
            for (int i = 0; i < n; i++) {
                if (i == pos_creator) {
                    array[pos_creator][i] += 0;
                } else {
                    array[pos_creator][i] += value *
                        Integer.parseInt(expense.getSharePart().get(i)) / tot_shares;
                }
            }
        }

        for (int i=0; i<n; i++) {
            for (int j=0; j<n; j++) {
                System.out.println("array["+i+"]["+j+"]="+array[i][j]);
                System.out.println("result["+i+"]["+j+"]="+result[i][j]);
                assertEquals(array[i][j], result[i][j]);
            }
        }
    }
}
