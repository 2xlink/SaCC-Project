package com.pion.app_login.activities;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.pion.app_login.User;
import com.pion.app_login.database.SQLiteHandler;
import com.pion.app_login.database.SessionManager;
import com.pion.app_login.database.UserDB;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Abstract class for all the activities of the project
 *
 * Created by pion on 24/01/16.
 */
abstract class AppActivity extends AppCompatActivity {

    protected ProgressDialog pDialog;
    protected SessionManager session;
    protected SQLiteHandler handler;
    protected User user;

    @Override
    public void onCreate(Bundle savedInstancesState) {
        super.onCreate(savedInstancesState);

        // Session Manager
        session = new SessionManager(getApplicationContext());
        // handler of the database
        handler = new SQLiteHandler(getApplicationContext());
        // user of the app
        if (session.isLoggedIn()) {
            user = (new UserDB(handler)).getUser();
        } else {
            user = new User();
        }

        // progress dialog
        pDialog = new ProgressDialog(this);
        pDialog.setCancelable(false);
    }

    protected void toLogin(Context context)
    {
        // user not logged in -> take him to the login activity
        Intent intent = new Intent(context, LoginActivity.class);
        startActivity(intent);
        finish();
    }

    /**
     * Check if the phone is connected or not
     * @return
     */
    protected boolean isNetworkAvailable()
    {
        ConnectivityManager connectivityManager = (ConnectivityManager)
                getSystemService(getApplicationContext().CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    /**
     * Show the progress dialog if not already shown
     * @param pDialog
     */
    protected static void showDialog(ProgressDialog pDialog)
    {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    /**
     * hide the progress dialog if already shown
     * @param pDialog
     */
    protected static void hideDialog(ProgressDialog pDialog)
    {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }

    /**
     * get datetime
     **/
    protected static String getDateTime() {
        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        Date date = new Date();
        return dateFormat.format(date);
    }
}
