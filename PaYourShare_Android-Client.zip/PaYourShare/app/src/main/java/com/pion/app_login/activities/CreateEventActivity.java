package com.pion.app_login.activities;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.ViewManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;

import com.pion.app_login.Event;
import com.pion.app_login.R;
import com.pion.app_login.UserToView;
import com.pion.app_login.app.AppConfig;
import com.pion.app_login.app.AppController;
import com.pion.app_login.app.HttpsTrustManager;
import com.pion.app_login.app.VolleyRequest;
import com.pion.app_login.database.EventsDB;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Activity to create a new event
 *
 * http://stackoverflow.com/questions/26765307/android-dynamically-add-buttons-to-layout
 * http://stackoverflow.com/questions/6216547/android-dynamically-add-views-into-view
 *
 * TODO allow to create an event without the app user as a participant to the event (??)
 *
 * Created by pion on 01/12/15.
 */
public class CreateEventActivity extends CreateActivity {
    private static final String TAG = CreateEventActivity.class.getSimpleName();

    private Toolbar toolbar;

    private EditText input_name;
    private EditText input_desc;

    private EditText name_part;

    private Event event;

    private List<String> ev_list_ids;
    private List<String> ev_list_emails;

    private List<TextView> list_email_tv;
    private List<ImageButton> list_rm_btn;
    private List<LinearLayout> list_layout_users;

    boolean bool = false;

    @Override
    public void onCreate(Bundle savedInstancesState)
    {
        super.onCreate(savedInstancesState);
        setContentView(R.layout.create_event);
        Log.d(TAG, "CreateEventActivity launched");

        // toolbar
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        // add a return button to go to the previous activity
        final ActionBar supportActionBar = getSupportActionBar();
        supportActionBar.setDisplayHomeAsUpEnabled(true);

        input_name = (EditText) findViewById(R.id.event_name);
        input_desc = (EditText) findViewById(R.id.event_desc);

        LinearLayout layout_add = (LinearLayout) findViewById(R.id.layout_add_participants);

        // input for the names of a new user
        UserToView.inputUserToView(this);
        name_part = UserToView.getInput();
        ImageButton add_part = UserToView.getAddButton();

        layout_add.addView(name_part);
        layout_add.addView(add_part);

        // create an empty event
        event = new Event();

        // lists of ids and emails of user of the creating event
        ev_list_ids = new ArrayList<>();
        ev_list_emails = new ArrayList<>();

        // lists of text views and buttons shown on the view
        // each correspond to a new user append to the event
        list_email_tv = new ArrayList<>();
        list_rm_btn = new ArrayList<>();
        list_layout_users = new ArrayList<>();

        // check if user already logged in or not
        if (session.isLoggedIn()) {

            // add the current user to the view
            addParticipantToView(user.getId(), user.getEmail());

            // Add participants
            // click the add_part button
            add_part.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final String new_email = name_part.getText().toString().trim();

                    if (!new_email.matches("")) { // if email not empty
                        if (!ev_list_emails.contains(new_email)) { // if email not already added
        // TODO when the connexion is available check if the new user already has an account or not
                            if (isNetworkAvailable()) { // if connection available
                                checkValidEmail(new_email);
                            } else {
                                // if no connection available
                                // show a box and ask the user if he really wants to add the user
                                Log.d(TAG, "No connection to internet");
                                Toast.makeText(getApplicationContext(),
                                        "No connection to internet, internet is required to add a participant", Toast.LENGTH_SHORT).show();

                                // TODO: add a virtual participant
                                /*DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        switch (which){
                                            case DialogInterface.BUTTON_POSITIVE:
                                                //Yes button clicked
                                                addParticipantToView(UUID.randomUUID().toString(), new_email);
                                                break;

                                            case DialogInterface.BUTTON_NEGATIVE:
                                                //No button clicked
                                                break;
                                        }
                                    }
                                };

                                AlertDialog.Builder builder = new AlertDialog.Builder(v.getContext());
                                builder.setMessage("Do you really want to add " + new_email + " to this event?")
                                        .setPositiveButton("Yes", dialogClickListener)
                                        .setNegativeButton("No", dialogClickListener).show();
                                    Log.d(TAG, "add part");
                                }*/
                            }
                        } else {
                            Toast.makeText(getApplicationContext(),
                                    "Participant already linked to the event", Toast.LENGTH_SHORT).show();

                            Log.d(TAG, "Participant already in event");
                        }

                    } else {
                        Toast.makeText(getApplicationContext(),
                                "Please fill the email of the new participant", Toast.LENGTH_SHORT).show();

                        Log.d(TAG, "No name to the new participant");
                    }

                    }
            });


        } else {
            // user not logged in -> take him to the login activity
            Log.d(TAG, "User is not logged in");
            toLogin(CreateEventActivity.this);
        }
    }

    /**
     * Check if the user has an account on the server database
     * @param email_user
     * @return
     */
    public void checkValidEmail(final String email_user)
    {
        HttpsTrustManager.allowAllSSL();

        // tag used to cancel the request
        String tag_string_req = "req_user_exists";

        pDialog.setMessage("Search for the user...");
        showDialog(pDialog);

        JSONObject jObj = null;
        try {
            jObj = new JSONObject("{\"email\":\"" + email_user + "\"}");

            String url = AppConfig.URL_USER_EXISTS;

            JsonObjectRequest jObjReq = new JsonObjectRequest(Request.Method.POST,
                    url, jObj, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                    Log.d(TAG, "Login Response: " + response.toString());
                    hideDialog(pDialog);

                    try {
                        boolean status = response.getBoolean("status");

                        // check the status of the answer in json
                        if (status) {
                            addParticipantToView(response.getString("id"), email_user);

                        } else {
                            Toast.makeText(getApplicationContext(),
                                    "This user doesn't have an account", Toast.LENGTH_LONG)
                                    .show();
                        }
                    } catch (JSONException e) {
                        // JSON error
                        e.printStackTrace();
                        Log.d(TAG, "JSON error " + e.getMessage());
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError errorV) {
                    Log.e(TAG, "Login volley request error: " + errorV.getMessage());
                    Toast.makeText(getApplicationContext(),
                            "Connection error, couldn't store the event on the server",
                            Toast.LENGTH_LONG).show();
                    hideDialog(pDialog);
                }
            });

            // Adding request to request queue
            AppController.getInstance().addToRequestQueue(jObjReq, tag_string_req);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void addParticipantToView(String id_user, String email_user)
    {
        LinearLayout layout_show_part = (LinearLayout)
                findViewById(R.id.layout_list_participants);

        // create the views representing each participant to the event
        UserToView.addUserToView(this, email_user);
        LinearLayout l_part = UserToView.getLayoutUser();
        TextView new_part = UserToView.getEmailView();
        final ImageButton rm_part = UserToView.getRmButton();

        // add the user to the lists of ids and emails
        ev_list_ids.add(id_user);
        ev_list_emails.add(email_user);
        Log.d(TAG, "listNames: " + ev_list_emails.toString()
                + " - listIds: " + ev_list_ids.toString());

        // store in lists of view and button in order to easily refer to them
        list_email_tv.add(new_part);
        list_rm_btn.add(rm_part);
        list_layout_users.add(l_part);

        // remove user of the event
        // it is a new event so each user is new to the event
        // /!\ the user must not be the creator of the event
        rm_part.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // get the position of the user in the lists of objects
                int i = list_rm_btn.indexOf(rm_part);

                // get the id and email to remove
                String rm_id = ev_list_ids.get(i);
                String rm_email = ev_list_emails.get(i);

                // check if the user is the creator of the event
                // i.e. the current user of the app
                // normally this can't append because the user of the app is not shown on the view
                if (rm_id.equals(user.getId())) {
                    Toast.makeText(getApplicationContext(),
                            "Could not remove the owner of the event",
                            Toast.LENGTH_SHORT).show();
                } else { // if not, the user can be safely removed of the event
                    // remove the layout from the view
                    ((ViewManager) list_layout_users.get(i).getParent()).
                            removeView(list_layout_users.get(i));

                    // remove the objects from the lists
                    list_layout_users.remove(i);
                    list_rm_btn.remove(i);
                    list_email_tv.remove(i);

                    // remove the user from the event object
                    ev_list_ids.remove(rm_id);
                    ev_list_emails.remove(rm_email);

                    // remove the button from the list
                    Log.d(TAG, "Participant removed from the event");

                    Log.d(TAG, "listIds: " + ev_list_ids.toString()
                            + " - listEmails: " + ev_list_emails.toString());
                }

            }
        });

        // add the layout to the view
        layout_show_part.addView(l_part);

        // reset the text of the edit text
        name_part.setText("");

    }


    /**
     * create event method
     * check if the fields are correctly fill and then create the event
     * or inform the user of an error, incorrect input
     */
    public void create()
    {
        String name = input_name.getText().toString().trim();
        String desc = input_desc.getText().toString().trim();

        // get the id of the current user of the app
        String id_creator = user.getId();

        if (!name.isEmpty()) {
            event.setId(UUID.randomUUID().toString()); // generate UUID
            //event.setId(""); // uid generated by server
            event.setName(name);
            event.setDesc((desc.isEmpty()) ? "" : desc);
            event.setIdCreator(id_creator);
            event.setIdUsers(ev_list_ids);
            event.setEmailUsers(ev_list_emails);
            event.setVersion(0);
            event.setCreatedAt(getDateTime());

            Log.d(TAG, "event: " + event.toString());

            if (isNetworkAvailable()) { // if connection available
                VolleyRequest vr = new VolleyRequest(getApplicationContext(), pDialog);
                vr.eventToServer(event, user.getToken(), AppConfig.URL_CREATE_EVENT, 0);
            } else {
                Log.d(TAG, "No connection to internet");
                Toast.makeText(getApplicationContext(),
                        "No connection to internet, couldn't store the event on the server", Toast.LENGTH_SHORT).show();
            }
            createLocalEvent(event);

            Intent intent = new Intent(CreateEventActivity.this, ShowEventActivity.class);
            intent.putExtra("event", event);
            setResult(Activity.RESULT_OK, intent);
            finish();

        } else {
            Toast.makeText(getApplicationContext(),
                    "Please give a name to the event", Toast.LENGTH_LONG).show();
        }
    }

    /**
     * Show a dialog box and ask the user if he really wants to add this participant
     * used when no onternet connection or when user not found in server database
     * @return
     */
    public boolean showAddPart(View v, String participant)
    {
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which){
                    case DialogInterface.BUTTON_POSITIVE:
                        //Yes button clicked
                        bool = true;
                        break;

                    case DialogInterface.BUTTON_NEGATIVE:
                        //No button clicked
                        bool = false;
                        break;
                }
            }
        };

        AlertDialog.Builder builder = new AlertDialog.Builder(v.getContext());
        builder.setMessage("Do you really want to add " + participant + " to this event?")
                .setPositiveButton("Yes", dialogClickListener)
                .setNegativeButton("No", dialogClickListener).show();

        return bool;
    }

    /**
     * Store in the local database the new event
     * @param event
     */
    public void createLocalEvent(Event event)
    {
        if (event != null) {
            (new EventsDB(handler)).addEvent(event);
            Log.d(TAG, "Event added to local database: " + event.toString());
        } else {
            Log.d(TAG, "Error: the event is null");
        }
    }

}
