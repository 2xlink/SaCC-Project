package com.pion.app_login.res;

import android.app.ProgressDialog;
import android.content.Context;

/**
 * Methods useful in the program
 *
 * Created by pion on 27/12/15.
 */
public class Resource {


    public static int dpToPx(Context context, int dp)
    {
        float scale = context.getResources().getDisplayMetrics().density;
        return (int) (dp * scale + 0.5f);

    }

    /**
     * Show the progress dialog if not already shown
     * @param pDialog
     */
    public static void showDialog(ProgressDialog pDialog)
    {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    /**
     * hide the progress dialog if already shown
     * @param pDialog
     */
    public static void hideDialog(ProgressDialog pDialog)
    {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }

}
