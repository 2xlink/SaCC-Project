CREATE TABLE events (
	id INT(11) PRIMARY KEY auto_increment,
   unique_id VARCHAR(23) NOT NULL UNIQUE,
	name VARCHAR(50) NOT NULL,
	description TEXT,
	id_creator INT(11) NOT NULL,
	id_list_users INT(11) NOT NULL,
	created_at DATETIME,
	updated_at DATETIME NULL
); /** Creating Events Table **/
	
